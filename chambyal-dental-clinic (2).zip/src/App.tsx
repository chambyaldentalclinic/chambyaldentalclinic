import { useState, useEffect } from 'react';
import Navbar from './components/Navbar';
import Footer from './components/Footer';
import FloatingActions from './components/FloatingActions';
import SEOHandler from './components/SEOHandler';

// Import Pages
import Home from './pages/Home';
import About from './pages/About';
import Services from './pages/Services';
import Doctor from './pages/Doctor';
import GalleryPage from './pages/GalleryPage';
import BookingPage from './pages/BookingPage';
import Contact from './pages/Contact';

import { AnimatePresence, motion } from 'motion/react';

export default function App() {
  const [currentPage, setCurrentPage] = useState<string>('home');
  const [selectedTreatment, setSelectedTreatment] = useState<string>('');

  // Auto-scroll to top on page swap
  useEffect(() => {
    window.scrollTo({ top: 0, behavior: 'instant' });
  }, [currentPage]);

  const renderActivePage = () => {
    switch (currentPage) {
      case 'home':
        return (
          <Home 
            setCurrentPage={setCurrentPage} 
            setSelectedTreatment={setSelectedTreatment} 
          />
        );
      case 'about':
        return <About />;
      case 'services':
        return (
          <Services 
            setCurrentPage={setCurrentPage} 
            setSelectedTreatment={setSelectedTreatment} 
          />
        );
      case 'doctor':
        return <Doctor setCurrentPage={setCurrentPage} />;
      case 'gallery':
        return <GalleryPage />;
      case 'booking':
        return (
          <BookingPage 
            selectedTreatment={selectedTreatment} 
            setSelectedTreatment={setSelectedTreatment} 
          />
        );
      case 'contact':
        return <Contact />;
      default:
        return (
          <Home 
            setCurrentPage={setCurrentPage} 
            setSelectedTreatment={setSelectedTreatment} 
          />
        );
    }
  };

  return (
    <div className="flex flex-col min-h-screen bg-[#F8FAFC] overflow-x-hidden selection:bg-blue-100 selection:text-blue-900" id="chambyal-clinical-app-wrapper">
      
      {/* 1. SEO Tag & Schema Injector */}
      <SEOHandler page={currentPage} />

      {/* 2. Sticky Header Area */}
      <Navbar currentPage={currentPage} setCurrentPage={setCurrentPage} />

      {/* 3. Immersive Main Page Arena with Smooth Slide transitions */}
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.35, ease: 'easeInOut' }}
          >
            {renderActivePage()}
          </motion.div>
        </AnimatePresence>
      </main>

      {/* 4. Multi-column descriptive Footer */}
      <Footer setCurrentPage={setCurrentPage} />

      {/* 5. Mobile Quick-Access Floating Widgets */}
      <FloatingActions />

    </div>
  );
}
