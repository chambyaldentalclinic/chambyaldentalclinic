import React, { useState } from 'react';
import { servicesData } from '../data';
import { Calendar, Clock, User, Phone, Mail, FileText, CheckCircle, Smartphone } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface AppointmentFormProps {
  initialTreatmentId?: string;
  onSuccessClose?: () => void;
}

export default function AppointmentForm({ 
  initialTreatmentId = '', 
  onSuccessClose 
}: AppointmentFormProps) {
  // Input states
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [date, setDate] = useState('');
  const [time, setTime] = useState('');
  const [treatment, setTreatment] = useState(initialTreatmentId);
  const [message, setMessage] = useState('');

  // Validation States
  const [errors, setErrors] = useState<{ [key: string]: string }>({});
  const [isSubmitSuccess, setIsSubmitSuccess] = useState(false);

  // Form validator
  const validateForm = () => {
    const newErrors: { [key: string]: string } = {};

    if (!name.trim()) {
      newErrors.name = 'Patient Name is required';
    } else if (name.trim().length < 3) {
      newErrors.name = 'Name must be at least 3 characters';
    }

    // Indian phone numbers are usually 10 digits
    const phonePattern = /^[6-9]\d{9}$/;
    if (!phone) {
      newErrors.phone = 'Mobile Number is required';
    } else if (!phonePattern.test(phone.replace(/\s+/g, ''))) {
      newErrors.phone = 'Please enter a valid 10-digit primary mobile number';
    }

    if (email) {
      const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
      if (!emailPattern.test(email)) {
        newErrors.email = 'Please enter a valid email address structure';
      }
    }

    if (!date) {
      newErrors.date = 'Preferred Appointment Date is required';
    } else {
      const selectedDate = new Date(date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (selectedDate < today) {
        newErrors.date = 'Appointment date cannot be in the past';
      }
    }

    if (!time) {
      newErrors.time = 'Preferred time slot is required';
    }

    if (!treatment) {
      newErrors.treatment = 'Please select a required dental service';
    }

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleOnlineSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      setIsSubmitSuccess(true);
      // Perfect localized storage tracking for user's own reference
      const localBooking = {
        name,
        phone,
        email,
        date,
        time,
        treatment: servicesData.find((s) => s.id === treatment)?.title || treatment,
        message,
        timestamp: new Date().toISOString()
      };
      
      const prevBookings = JSON.parse(localStorage.getItem('chambyal_dental_bookings') || '[]');
      localStorage.setItem('chambyal_dental_bookings', JSON.stringify([...prevBookings, localBooking]));
    }
  };

  const handleWhatsAppSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (validateForm()) {
      const selectedTreatmentTitle = servicesData.find((s) => s.id === treatment)?.title || treatment;
      const originalText = `Hello Chambyal Dental Clinic, I would like to confirm a Dental checkup appointment:
- *Patient Name:* ${name.trim()}
- *Mobile:* ${phone.trim()}
- *Email:* ${email.trim() || 'Not Provided'}
- *Date:* ${date}
- *Time Slot:* ${time}
- *Required Treatment:* ${selectedTreatmentTitle}
- *Message:* ${message.trim() || 'No additional details'}`;

      const whatsappUrl = `https://wa.me/919459778337?text=${encodeURIComponent(originalText)}`;
      window.open(whatsappUrl, '_blank');
      setIsSubmitSuccess(true);
    }
  };

  const handleSuccessReset = () => {
    setIsSubmitSuccess(false);
    setName('');
    setPhone('');
    setEmail('');
    setDate('');
    setTime('');
    setTreatment('');
    setMessage('');
    setErrors({});
    if (onSuccessClose) onSuccessClose();
  };

  // Get active date boundary (today)
  const getTodayString = () => {
    const today = new Date();
    const dd = String(today.getDate()).padStart(2, '0');
    const mm = String(today.getMonth() + 1).padStart(2, '0'); 
    const yyyy = today.getFullYear();
    return `${yyyy}-${mm}-${dd}`;
  };

  return (
    <div className="relative bg-white rounded-3xl p-6 sm:p-10 border border-slate-100 shadow-2xl overflow-hidden" id="appointment-booking-box">
      {/* Decorative colored visual elements */}
      <div className="absolute top-0 left-0 w-full h-1.5 bg-gradient-to-r from-[#0F4C81] to-[#20B2AA]"></div>
      
      <div className="mb-6">
        <h3 className="text-2xl font-bold text-slate-900 tracking-tight">Schedule Your Consultation</h3>
        <p className="text-slate-500 text-sm mt-1">
          Complete the patient details below. We will confirm your appointment within 2 working hours.
        </p>
      </div>

      <form className="space-y-5">
        {/* Patient Name */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
            <User className="w-3.5 h-3.5 text-[#0F4C81]" /> Patient Full Name*
          </label>
          <input
            type="text"
            required
            id="form-patient-name"
            placeholder="e.g. Amit Sharma"
            value={name}
            onChange={(e) => setName(e.target.value)}
            className={`w-full px-4 py-3 border rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 transition-all focus:outline-none focus:ring-2 ${
              errors.name 
                ? 'border-rose-300 focus:ring-rose-200 focus:bg-white' 
                : 'border-slate-200 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]'
            }`}
          />
          {errors.name && <span className="text-rose-500 text-xs mt-1 block">{errors.name}</span>}
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Mobile Number */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
              <Phone className="w-3.5 h-3.5 text-[#0F4C81]" /> Mobile Number*
            </label>
            <div className="relative">
              <span className="absolute left-3.5 top-3.5 text-slate-400 text-sm font-medium">+91</span>
              <input
                type="tel"
                required
                maxLength={10}
                id="form-patient-phone"
                placeholder="9876543210"
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                className={`w-full pl-12 pr-4 py-3 border rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 transition-all focus:outline-none focus:ring-2 ${
                  errors.phone 
                    ? 'border-rose-300 focus:ring-rose-200 focus:bg-white' 
                    : 'border-slate-200 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]'
                }`}
              />
            </div>
            {errors.phone && <span className="text-rose-500 text-xs mt-1 block">{errors.phone}</span>}
          </div>

          {/* Email Address */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
              <Mail className="w-3.5 h-3.5 text-[#0F4C81]" /> Email Address (Optional)
            </label>
            <input
              type="email"
              id="form-patient-email"
              placeholder="e.g. amit@gmail.com"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              className={`w-full px-4 py-3 border rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 transition-all focus:outline-none focus:ring-2 ${
                errors.email 
                  ? 'border-rose-300 focus:ring-rose-200 focus:bg-white' 
                  : 'border-slate-200 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]'
              }`}
            />
            {errors.email && <span className="text-rose-500 text-xs mt-1 block">{errors.email}</span>}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-5">
          {/* Preferred Date */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
              <Calendar className="w-3.5 h-3.5 text-[#0F4C81]" /> Preferred Date*
            </label>
            <input
              type="date"
              required
              id="form-patient-date"
              min={getTodayString()}
              value={date}
              onChange={(e) => setDate(e.target.value)}
              className={`w-full px-4 py-3 border rounded-xl text-slate-850 bg-slate-50 transition-all focus:outline-none focus:ring-2 ${
                errors.date 
                  ? 'border-rose-300 focus:ring-rose-200 focus:bg-white' 
                  : 'border-slate-200 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]'
              }`}
            />
            {errors.date && <span className="text-rose-500 text-xs mt-1 block">{errors.date}</span>}
          </div>

          {/* Preferred Time */}
          <div>
            <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
              <Clock className="w-3.5 h-3.5 text-[#0F4C81]" /> Preferred Time Slot*
            </label>
            <select
              required
              id="form-patient-time"
              value={time}
              onChange={(e) => setTime(e.target.value)}
              className={`w-full px-4 py-3 border rounded-xl text-slate-700 bg-slate-50 transition-all focus:outline-none focus:ring-2 ${
                errors.time 
                  ? 'border-rose-300 focus:ring-rose-200 focus:bg-white' 
                  : 'border-slate-200 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]'
              }`}
            >
              <option value="">-- Select Time Slot --</option>
              <option value="Morning (09:45 AM - 12:30 PM)">Morning (09:45 AM - 12:30 PM)</option>
              <option value="Afternoon (12:30 PM - 03:30 PM)">Afternoon (12:30 PM - 03:30 PM)</option>
              <option value="Evening (03:30 PM - 06:15 PM)">Evening (03:30 PM - 06:15 PM)</option>
            </select>
            {errors.time && <span className="text-rose-500 text-xs mt-1 block">{errors.time}</span>}
          </div>
        </div>

        {/* Treatment Required */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5 flex items-center gap-1.5">
            <FileText className="w-3.5 h-3.5 text-[#0F4C81]" /> Required Dental Treatment*
          </label>
          <select
            required
            id="form-patient-treatment"
            value={treatment}
            onChange={(e) => setTreatment(e.target.value)}
            className={`w-full px-4 py-3 border rounded-xl text-slate-700 bg-slate-50 transition-all focus:outline-none focus:ring-2 ${
              errors.treatment 
                ? 'border-rose-300 focus:ring-rose-200 focus:bg-white' 
                : 'border-slate-200 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]'
            }`}
          >
            <option value="">-- Select Treatment / Service --</option>
            {servicesData.map((ser) => (
              <option key={ser.id} value={ser.id}>
                {ser.title}
              </option>
            ))}
            <option value="other-consultation">General Dental Evaluation & Pain Consultation</option>
          </select>
          {errors.treatment && <span className="text-rose-500 text-xs mt-1 block">{errors.treatment}</span>}
        </div>

        {/* Short message */}
        <div>
          <label className="block text-xs font-semibold text-slate-700 uppercase tracking-widest mb-1.5">
            Brief Message or Dental Symptoms (Optional)
          </label>
          <textarea
            id="form-patient-message"
            placeholder="Describe your dental discomfort or question e.g. toothache in back tooth, or looking for cosmetic veneers..."
            value={message}
            onChange={(e) => setMessage(e.target.value)}
            rows={3}
            className="w-full px-4 py-3 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 transition-all focus:outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white focus:border-[#0F4C81]"
          />
        </div>

        {/* Submission Panel */}
        <div className="flex flex-col sm:flex-row gap-4 pt-2">
          {/* Main Booking via Portal */}
          <button
            type="submit"
            onClick={handleOnlineSubmit}
            id="btn-confirm-online-booking"
            className="flex-1 py-4.5 px-6 rounded-xl bg-[#0F4C81] text-white font-bold text-center text-sm shadow-xl hover:bg-[#0c3e6b] hover:shadow-2xl hover:shadow-blue-200 transition-all active:scale-98"
          >
            Request Appointment
          </button>

          {/* Quick WhatsApp Link Bridge */}
          <button
            type="button"
            onClick={handleWhatsAppSubmit}
            id="btn-confirm-whatsapp-booking"
            className="flex-1 py-4.5 px-6 rounded-xl bg-emerald-50 text-emerald-800 border border-emerald-200 font-bold text-center text-sm flex items-center justify-center gap-2 hover:bg-emerald-100 hover:text-emerald-900 transition-all active:scale-98"
          >
            <Smartphone className="w-4.5 h-4.5 text-emerald-600" />
            Book Instantly via WhatsApp
          </button>
        </div>
      </form>

      {/* Modern Dialog Success Modal */}
      <AnimatePresence>
        {isSubmitSuccess && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="absolute inset-0 bg-[#0F4C81]/98 z-35 flex flex-col items-center justify-center text-center p-8"
          >
            <motion.div
              initial={{ scale: 0.8, y: 30 }}
              animate={{ scale: 1, y: 0 }}
              exit={{ scale: 0.8, y: 30 }}
              transition={{ type: 'spring', duration: 0.4 }}
              className="max-w-md flex flex-col items-center"
            >
              <div className="p-4 bg-emerald-500 rounded-full text-white shadow-2xl shadow-emerald-500/50 mb-6">
                <CheckCircle className="w-12 h-12" />
              </div>
              <h4 className="text-3xl font-extrabold text-white tracking-tight">Request Received!</h4>
              <p className="text-blue-100 text-sm mt-3 px-2 line-clamp-4">
                Thank you, <span className="font-bold text-teal-300">{name}</span>! Your dental consultation slot on{' '}
                <span className="font-bold text-teal-300">{date}</span> ({time.split(' ')[0]}) is being registered. 
                Our hospitality desk will verify the slot and text you via SMS/WhatsApp shortly.
              </p>

              <div className="mt-8 flex flex-col w-full gap-3">
                <a
                  href="tel:+919459778337"
                  className="px-6 py-3.5 bg-teal-400 hover:bg-teal-500 text-slate-900 font-bold rounded-xl shadow-lg transition-all text-sm"
                >
                  Urgent? Call Us Now
                </a>
                <button
                  type="button"
                  onClick={handleSuccessReset}
                  className="px-6 py-3 bg-white/10 hover:bg-white/20 text-white font-semibold rounded-xl text-xs transition-all tracking-wider uppercase"
                >
                  Return to Reservation Form
                </button>
              </div>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
