import React from 'react';

interface ClinicLogoProps {
  className?: string;
  iconOnly?: boolean;
  lightBackground?: boolean;
}

export default function ClinicLogo({ className = 'w-11 h-11', iconOnly = false, lightBackground = true }: ClinicLogoProps) {
  // Cyan/teal top crown color: #00A8C6 or #20B2AA or #30c2e3
  // Grey roots color: #8C8C8C or #94A3B8
  const cyanColor = '#00B4D8';
  const greyColor = '#8A8A8A';

  if (iconOnly) {
    return (
      <svg 
        viewBox="0 0 100 100" 
        fill="none" 
        xmlns="http://www.w3.org/2000/svg" 
        className={className}
        id="clinical-tooth-logo-vector"
      >
        {/* Top crown cusp contour (blue/cyan) */}
        <path 
          d="M18 50 C18 40, 24 35, 34 35 C42 35, 46 41, 50 44 C54 41, 58 35, 66 35 C76 35, 82 40, 82 50 C82 54, 76 54, 72 54 C61 54, 58 54, 50 54 C42 54, 39 54, 28 54 C24 54, 18 54, 18 50 Z" 
          fill={cyanColor} 
        />
        {/* Connection line helper curves */}
        <path 
          d="M18 48 C18 64, 32 64, 38 68 C44 72, 44 86, 50 86 C56 86, 56 72, 62 68 C68 64, 82 64, 82 48" 
          stroke={greyColor} 
          strokeWidth="6" 
          strokeLinecap="round" 
          strokeLinejoin="round"
        />
        {/* Top crest overlay line to define the tooth cusps elegantly */}
        <path 
          d="M20 50 C24 40, 36 38, 48 45 C52 45, 56 40, 68 38 C80 40, 80 50, 80 50" 
          stroke="white" 
          strokeWidth="3" 
          strokeLinecap="round"
        />
      </svg>
    );
  }

  // Full composite logo drawing matching the user's uploaded logo layout exactly
  return (
    <div className={`flex flex-col items-center justify-center p-4 text-center ${lightBackground ? 'bg-white' : 'bg-slate-900'} rounded-2xl border border-slate-100 shadow-sm`} id="full-composite-clinic-logo">
      <div className="relative w-48 h-32 flex items-center justify-center">
        {/* Ambient watermark tooth sketch from uploaded logo */}
        <svg 
          viewBox="0 0 100 100" 
          fill="none" 
          xmlns="http://www.w3.org/2000/svg" 
          className="absolute inset-0 w-full h-full opacity-15 pointer-events-none select-none"
        >
          {/* Top blue/cyan crown */}
          <path 
            d="M20 48 Q35 34, 50 45 Q65 34, 80 48" 
            stroke={cyanColor} 
            strokeWidth="5" 
            strokeLinecap="round"
          />
          {/* Bottom grey roots */}
          <path 
            d="M20 48 Q22 68, 38 72 Q44 73, 44 86 Q50 86, 50 82 Q56 86, 56 86 Q56 73, 62 72 Q78 68, 80 48" 
            stroke={greyColor} 
            strokeWidth="5" 
            strokeLinecap="round"
          />
        </svg>

        {/* Foreground Core styled typography exactly following original sketched text */}
        <div className="z-10 flex flex-col items-center justify-center">
          <h2 className="text-lg font-black tracking-tight text-[#00A8C6] drop-shadow-sm leading-none m-0">
            CHAMBYAL DENTAL CLINIC
          </h2>
          <p className="text-[9px] font-bold text-emerald-600 tracking-tight leading-snug mt-1.5 uppercase">
            Centre for Advanced Dentistry & Implantology
          </p>
          <div className="flex items-center gap-1.5 mt-2">
            <span className="h-[1px] w-6 bg-[#00B4D8]/30"></span>
            <span className="text-[10px] font-black text-slate-800 tracking-wider">
              Since 1997
            </span>
            <span className="h-[1px] w-6 bg-[#00B4D8]/30"></span>
          </div>
        </div>
      </div>
    </div>
  );
}
