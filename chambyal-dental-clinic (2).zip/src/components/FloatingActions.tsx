import { useState, useEffect } from 'react';
import { Phone, ArrowUp } from 'lucide-react';

export default function FloatingActions() {
  const [showScrollTop, setShowScrollTop] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      if (window.scrollY > 400) {
        setShowScrollTop(true);
      } else {
        setShowScrollTop(false);
      }
    };

    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const clinicPhone = '+919459778337';
  const whatsappText = encodeURIComponent(
    'Hello Chambyal Dental Clinic. I would like to book a dental checkup consultation.'
  );
  const whatsappUrl = `https://wa.me/919459778337?text=${whatsappText}`;

  return (
    <div className="fixed bottom-6 right-6 z-50 flex flex-col gap-3 items-end">
      {/* Scroll to Top */}
      {showScrollTop && (
        <button
          onClick={scrollToTop}
          className="p-3 bg-white hover:bg-slate-50 text-slate-800 rounded-full shadow-lg border border-slate-100 transition-all duration-300 hover:scale-110 focus:outline-none"
          title="Scroll to top"
          aria-label="Scroll to top"
          id="btn-scroll-top"
        >
          <ArrowUp className="w-5 h-5 text-slate-700" />
        </button>
      )}

      {/* Floating Call Now */}
      <a
        href={`tel:${clinicPhone}`}
        className="flex items-center gap-2 px-4 py-3 bg-[#0F4C81] text-white rounded-full shadow-xl hover:bg-[#0c3e6b] transition-all duration-300 hover:scale-105"
        title="Call Clinic Executive"
        id="btn-floating-call"
      >
        <Phone className="w-5 h-5 fill-current animate-pulse" />
        <span className="text-sm font-semibold tracking-wide hidden sm:inline">Call Now</span>
      </a>

      {/* Floating WhatsApp Consultation */}
      <a
        href={whatsappUrl}
        target="_blank"
        rel="noopener noreferrer"
        className="flex items-center gap-2 px-4 py-3 bg-[#25D366] text-white rounded-full shadow-xl hover:bg-emerald-600 transition-all duration-300 hover:scale-105"
        title="WhatsApp Consultation Expert"
        id="btn-floating-whatsapp"
      >
        {/* Custom highly premium SVG markup for official WhatsApp branding */}
        <svg
          className="w-5 h-5 fill-current"
          viewBox="0 0 24 24"
          xmlns="http://www.w3.org/2000/svg"
        >
          <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.717-1.456L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.968C16.632 1.97 14.161.947 11.537.947c-5.443 0-9.87 4.372-9.874 9.802-.001 1.737.478 3.43 1.385 4.921L1.937 21.08l5.71-1.926z" />
        </svg>
        <span className="text-sm font-semibold tracking-wide hidden sm:inline">WhatsApp Help</span>
      </a>
    </div>
  );
}
