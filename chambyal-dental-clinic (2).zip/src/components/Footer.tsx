import { Phone, Mail, MapPin, Clock, ExternalLink, ChevronRight, MessageSquare } from 'lucide-react';
import ClinicLogo from './ClinicLogo';

interface FooterProps {
  setCurrentPage: (page: string) => void;
}

export default function Footer({ setCurrentPage }: FooterProps) {
  const handlePageSwap = (pageId: string) => {
    setCurrentPage(pageId);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  const addressText = 'Chambyal Dental Clinic, Main Market Barsar, Near Bus Stand, Barsar, Hamirpur, Himachal Pradesh - 174305';
  const phone = '+919459778337';
  const secondaryPhone = '+919418366088';
  const email = 'ankushchambyal@gmail.com';
  const mapLink = 'https://maps.app.goo.gl/BoWTSAnezZBmPDXF8';
  const reviewLink = 'https://g.page/r/CXRLNZdDCtebEBM/review';

  return (
    <footer className="bg-slate-950 text-slate-350 border-t border-slate-900" id="main-application-footer">
      
      {/* Upper informational ribbon */}
      <div className="bg-[#0F4C81] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-5 md:py-6 flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-white/10 flex items-center justify-center">
              <Clock className="w-5 h-5 text-teal-300" />
            </div>
            <div>
              <p className="font-semibold text-sm leading-none">Emergency Trauma & Pain Cases Available</p>
              <p className="text-blue-100 text-xs mt-1">24/7 call assistance to relieve absolute distress.</p>
            </div>
          </div>
          <a
            href={`tel:${phone}`}
            className="flex items-center gap-2.5 px-5 py-2.5 bg-slate-950/45 hover:bg-slate-950/60 rounded-full border border-white/15 text-white text-xs font-bold tracking-wider uppercase transition-colors"
          >
            <Phone className="w-4 h-4 text-teal-300" />
            Emergency Hotline: {phone}
          </a>
        </div>
      </div>

      {/* Main footer bento links block */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          
          {/* Brand block */}
          <div className="space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-10 h-10 bg-slate-800 rounded-lg flex items-center justify-center border border-slate-700/60 shadow-inner">
                <ClinicLogo iconOnly className="w-8 h-8" />
              </div>
              <div>
                <span className="text-white text-base font-black tracking-tight block">Chambyal</span>
                <span className="text-[#00B4D8] text-xs tracking-wider uppercase block font-bold leading-none mt-1">Dental Clinic</span>
              </div>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed pt-2">
              Chambyal Dental Clinic is the most trusted dental clinic located in Barsar, Hamirpur. We provide advanced, clinical-grade prosthodontic, endodontic, implant, Orthodontic, and pediatric therapies.
            </p>
            
            {/* Social Icons */}
            <div className="flex items-center gap-3 pt-3">
              <a
                href="https://facebook.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-[#20B2AA] hover:bg-slate-800 hover:text-white transition-colors"
                title="Follow Chambyal Dental on Facebook"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M22 12c0-5.52-4.48-10-10-10S2 6.48 2 12c0 4.84 3.44 8.87 8 9.8V15H8v-3h2V9.5C10 7.57 11.57 6 13.5 6H16v3h-2c-.55 0-1 .45-1 1v2h3v3h-3v6.95c4.56-.93 8-4.96 8-9.75z" />
                </svg>
              </a>
              <a
                href="https://instagram.com"
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-[#20B2AA] hover:bg-slate-800 hover:text-white transition-colors"
                title="Follow Chambyal Dental on Instagram"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12 2.163c3.204 0 3.584.012 4.85.07 3.252.148 4.771 1.691 4.919 4.919.058 1.265.069 1.645.069 4.849 0 3.205-.012 3.584-.069 4.849-.149 3.225-1.664 4.771-4.919 4.919-1.266.058-1.644.07-4.85.07-3.204 0-3.584-.012-4.849-.07-3.26-.149-4.771-1.699-4.919-4.92-.058-1.265-.07-1.644-.07-4.849 0-3.204.013-3.583.07-4.849.149-3.227 1.664-4.771 4.919-4.919 1.266-.057 1.645-.069 4.849-.069zM12 0C8.741 0 8.333.014 7.053.072 2.695.272.273 2.69.073 7.051.014 8.333 0 8.741 0 12c0 3.259.014 3.668.072 4.948.2 4.358 2.618 6.78 6.98 6.98 1.281.058 1.689.072 4.948.072 3.259 0 3.668-.014 4.948-.072 4.354-.2 6.782-2.618 6.979-6.98.059-1.28.073-1.689.073-4.948 0-3.259-.014-3.667-.072-4.947-.196-4.354-2.617-6.78-6.979-6.98C15.668.014 15.259 0 12 0zm0 5.838a6.162 6.162 0 100 12.324 6.162 6.162 0 000-12.324zM12 16a4 4 0 110-8 4 4 0 010 8zm6.406-11.845a1.44 1.44 0 100 2.881 1.44 1.44 0 000-2.881z" />
                </svg>
              </a>
              <a
                href={`https://wa.me/919459778337`}
                target="_blank"
                rel="noopener noreferrer"
                className="w-10 h-10 rounded-full bg-slate-900 border border-slate-800 flex items-center justify-center text-[#20B2AA] hover:bg-slate-800 hover:text-white transition-colors"
                title="Connect via WhatsApp Messenger"
              >
                <svg className="w-5 h-5 fill-current" viewBox="0 0 24 24">
                  <path d="M12.031 6.172c-3.181 0-5.767 2.586-5.768 5.766-.001 1.298.431 2.5 1.157 3.472l-.759 2.775 2.846-.746c.934.509 2.015.8 3.161.801 3.181 0 5.767-2.586 5.768-5.767a5.772 5.772 0 00-5.768-5.766zm3.435 8.163c-.15.421-.75.767-1.101.815-.951.13-2.091-.252-3.151-1.332-1.06-1.08-1.551-2.191-1.46-3.141.03-.35.401-.734.801-.856.241-.07.41.02.501.11.16.16.711 1.741.771 1.86.06.12-.01.271-.09.381-.07.1-.14.172-.25.3-.11.121-.24.25-.1.491.13.23.591.97.1.51.58.55 1.091.951 1.5.15.2.35.331.42.181.1-.19.421-.55.571-.741.13-.17.271-.14.44-.08.17.06 1.081.51 1.261.6.18.09.3.13.35.21.051.1-.11.53-.26.91z" />
                </svg>
              </a>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-widest mb-5">Quick Portal Navigation</h4>
            <ul className="space-y-3 font-medium text-sm">
              {[
                { id: 'home', label: 'Clinician Home' },
                { id: 'about', label: 'About Clinicians' },
                { id: 'services', label: 'Core Treatments' },
                { id: 'doctor', label: 'Dr. Ankush Biography' },
                { id: 'gallery', label: 'Before & After Smile' },
                { id: 'contact', label: 'Hours & Access Form' }
              ].map((link) => (
                <li key={link.id}>
                  <button
                    onClick={() => handlePageSwap(link.id)}
                    className="flex items-center gap-1.5 text-slate-400 hover:text-white transition-all text-left"
                    id={`footer-link-${link.id}`}
                  >
                    <ChevronRight className="w-3.5 h-3.5 text-[#20B2AA]" />
                    <span>{link.label}</span>
                  </button>
                </li>
              ))}
            </ul>
          </div>

          {/* Direct Address / Contact Details */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-widest mb-5">Contact Details</h4>
            <ul className="space-y-4 text-sm text-slate-400">
              <li className="flex items-start gap-2.5">
                <MapPin className="w-5 h-5 text-[#20B2AA] shrink-0 mt-0.5" />
                <span className="leading-relaxed">{addressText}</span>
              </li>
              <li className="flex items-center gap-2.5">
                <Phone className="w-4 h-4 text-[#20B2AA]" />
                <a href={`tel:${phone}`} className="hover:text-white">
                  +91 94597 78337
                </a>
              </li>
              <li className="flex items-center gap-2.5">
                <Mail className="w-4 h-4 text-[#20B2AA]" />
                <a href={`mailto:${email}`} className="hover:text-white">
                  {email}
                </a>
              </li>
            </ul>
          </div>

          {/* Direction / Location Maps Embed */}
          <div>
            <h4 className="text-white text-xs font-bold uppercase tracking-widest mb-5 font-semibold">Clinic Directions</h4>
            <div className="space-y-4">
              <p className="text-xs text-slate-400 leading-normal">
                Located near Barsar Bus Stand, Hamirpur. Click below to launch direct navigation or provide a Google review feedback.
              </p>
              <div className="flex flex-col gap-2.5">
                <a
                  href={mapLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-white rounded-xl text-xs font-semibold border border-slate-800 transition-colors"
                >
                  <span className="flex items-center gap-2">
                    <MapPin className="w-3.5 h-3.5 text-red-400" />
                    Open in Google Maps
                  </span>
                  <ExternalLink className="w-3C.5 h-3.5 text-slate-500" />
                </a>
                <a
                  href={reviewLink}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex items-center justify-between px-4 py-2.5 bg-slate-900 hover:bg-slate-800 text-teal-400 rounded-xl text-xs font-semibold border border-slate-800 transition-colors animate-pulse"
                >
                  <span className="flex items-center gap-2 text-teal-400">
                    <MessageSquare className="w-3.5 h-3.5" />
                    Rate Us on Google
                  </span>
                  <ExternalLink className="w-3.5 h-3.5 text-slate-500" />
                </a>
              </div>
            </div>
          </div>

        </div>

        {/* Lower registration and credits */}
        <div className="mt-12 pt-8 border-t border-slate-900 flex flex-col md:flex-row items-center justify-between gap-4 text-center md:text-left text-xs text-slate-500 font-medium">
          <div>
            <p>© {new Date().getFullYear()} Chambyal Dental Clinic. All Rights Reserved.</p>
            <p className="mt-1 text-[10px] text-slate-600">
              Licensed Dental Practitioners, Government Registered Clinic under Himachal Pradesh State Dental Council.
            </p>
          </div>
          <div className="flex gap-4">
            <button onClick={() => handlePageSwap('contact')} className="hover:text-slate-350">Clinic Location</button>
            <span>•</span>
            <button onClick={() => handlePageSwap('booking')} className="hover:text-slate-350 font-bold text-teal-400">Appointment Portal</button>
          </div>
        </div>

      </div>
    </footer>
  );
}
