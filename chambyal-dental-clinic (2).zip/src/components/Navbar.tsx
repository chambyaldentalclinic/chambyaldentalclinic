import { useState } from 'react';
import { Menu, X, Calendar, Phone } from 'lucide-react';
import ClinicLogo from './ClinicLogo';

interface NavbarProps {
  currentPage: string;
  setCurrentPage: (page: string) => void;
}

export default function Navbar({ currentPage, setCurrentPage }: NavbarProps) {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { id: 'home', label: 'Home' },
    { id: 'about', label: 'About Clinic' },
    { id: 'services', label: 'Dental Services' },
    { id: 'doctor', label: 'Meet Doctors' },
    { id: 'gallery', label: 'Smile Gallery' },
    { id: 'contact', label: 'Contact Us' }
  ];

  const handleNavigate = (pageId: string) => {
    setCurrentPage(pageId);
    setIsOpen(false);
    window.scrollTo({ top: 0, behavior: 'instant' });
  };

  return (
    <header className="sticky top-0 z-40 w-full transition-all duration-300 bg-white/90 backdrop-blur-md border-b border-slate-150/70" id="header-navigation">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-20">
          
          {/* Brand Logo & Clinician Identity */}
          <div 
            onClick={() => handleNavigate('home')} 
            className="flex items-center gap-3 cursor-pointer group"
            id="brand-identity-home-trigger"
          >
            {/* Custom Styled Clinic Logo matching user sketch */}
            <div className="w-11 h-11 bg-white border border-slate-100 rounded-xl flex items-center justify-center shadow-md shadow-blue-900/5 transition-transform group-hover:scale-105">
              <ClinicLogo iconOnly className="w-9 h-9" />
            </div>
            <div>
              <span className="text-lg font-black tracking-tight text-slate-900 leading-none block">
                Chambyal
              </span>
              <span className="text-xs font-bold tracking-wider text-[#00B4D8] uppercase block leading-none mt-1">
                Dental Clinic
              </span>
            </div>
          </div>

          {/* Desktop Navigation Link Tabs */}
          <nav className="hidden lg:flex items-center gap-7">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavigate(link.id)}
                  className={`text-sm font-semibold tracking-wide relative py-2 transition-all duration-200 ${
                    isActive 
                      ? 'text-[#0F4C81]' 
                      : 'text-slate-600 hover:text-slate-900'
                  }`}
                  id={`nav-link-${link.id}`}
                >
                  {link.label}
                  {/* Underline indicators */}
                  {isActive && (
                    <span className="absolute bottom-0 left-0 w-full h-0.5 bg-[#0F4C81] rounded-full"></span>
                  )}
                </button>
              );
            })}
          </nav>

          {/* Action CTAs */}
          <div className="hidden lg:flex items-center gap-4">
            <a 
              href="tel:+919459778337" 
              className="flex items-center gap-2 text-slate-700 hover:text-[#0F4C81] font-semibold text-[13px] mr-2 transition-colors"
              id="header-direct-call-link"
            >
              <Phone className="w-4 h-4 text-[#20B2AA]" />
              <span>+91 94597 78337</span>
            </a>
            
            <button
              onClick={() => handleNavigate('booking')}
              className="px-5 py-2.5 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white text-sm font-semibold rounded-full shadow-md shadow-blue-900/10 hover:shadow-lg transition-all hover:scale-[1.02] active:scale-98 flex items-center gap-2"
              id="header-book-cta-pill"
            >
              <Calendar className="w-4 h-4" />
              <span>Book Appointment</span>
            </button>
          </div>

          {/* Mobile Hamburg Trigger */}
          <div className="flex lg:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-xl text-slate-600 hover:text-slate-900 focus:outline-none"
              aria-expanded={isOpen}
              id="mobile-hamburger-trigger"
            >
              {isOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
            </button>
          </div>

        </div>
      </div>

      {/* Mobile Sticky Dropdown Drawer */}
      {isOpen && (
        <div className="lg:hidden bg-white border-t border-slate-100 shadow-xl transition-all duration-300" id="mobile-nav-panel">
          <div className="px-4 pt-4 pb-6 space-y-2">
            {navLinks.map((link) => {
              const isActive = currentPage === link.id;
              return (
                <button
                  key={link.id}
                  onClick={() => handleNavigate(link.id)}
                  className={`block w-full text-left px-4 py-3 rounded-xl text-sm font-bold tracking-wide transition-all ${
                    isActive 
                      ? 'bg-blue-50/75 text-[#0F4C81]' 
                      : 'text-slate-700 hover:bg-slate-50'
                  }`}
                  id={`mobile-nav-link-${link.id}`}
                >
                  {link.label}
                </button>
              );
            })}
            
            <div className="pt-4 border-t border-slate-100 flex flex-col gap-3">
              <a
                href="tel:+919459778337"
                className="flex items-center justify-center gap-2 text-slate-800 font-bold py-3 border border-slate-200 rounded-xl bg-slate-50 text-sm hover:bg-slate-100"
              >
                <Phone className="w-4 h-4 text-[#0F4C81]" />
                Call +91 94597 78337
              </a>
              <button
                onClick={() => handleNavigate('booking')}
                className="w-full py-3 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white font-bold text-center rounded-xl text-sm flex items-center justify-center gap-2 shadow-md"
              >
                <Calendar className="w-4 h-4" />
                Book Secure Appointment
              </button>
            </div>
          </div>
        </div>
      )}
    </header>
  );
}
