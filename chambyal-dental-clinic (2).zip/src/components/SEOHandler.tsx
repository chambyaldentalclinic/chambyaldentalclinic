import { useEffect } from 'react';

interface SEOProps {
  page: string;
}

export default function SEOHandler({ page }: SEOProps) {
  useEffect(() => {
    // 1. Determine Title and Description
    let title = 'Chambyal Dental Clinic | Best Dentist in Barsar, Hamirpur, HP';
    let description =
      'Experience the best dental care at Chambyal Dental Clinic in Barsar, Hamirpur, Himachal Pradesh. Led by Dr. Ankush Chambyal, specializing in painless implants, root canals, braces, and smile designing.';

    switch (page) {
      case 'about':
        title = 'About Dr. Ankush Chambyal & Team | Chambyal Dental Clinic Barsar';
        description =
          'Learn about Chambyal Dental Clinic, our state-of-the-art sterilization, modern technology, and our clinic safety protocols under senior dentist Dr. Ankush Chambyal.';
        break;
      case 'services':
        title = 'Advanced Dental Services in Hamirpur | Implants, RCT, Aligners';
        description =
          'Comprehensive dental treatments including titanium dental implants, rotary root canal (RCT), expert teeth whitening, invisible braces, pediatric care, and smile design in Himachal.';
        break;
      case 'doctor':
        title = 'Meet Dr. Ankush Chambyal - MDS Periodontics | Dentist in Barsar';
        description =
          'An expert MDS in Periodontology and Oral Implantology with 11+ years of clinical excellence. Dr. Ankush Chambyal offers high-tech pain-free dental solutions in Barsar, HP.';
        break;
      case 'gallery':
        title = 'Smile Transformations & Clinic Tour | Chambyal Dental Clinic';
        description =
          'Browse our smile gallery showing aesthetic before/after smile designs, and tour our state-of-the-art clinic sterilization setup and dental operatories in Barsar.';
        break;
      case 'booking':
        title = 'Book Dental Appointment Online | Chambyal Dental Clinic Barsar';
        description =
          'Schedule an online dental consultation with Dr. Ankush Chambyal. Fast, convenient booking option with direct WhatsApp confirmation and instant phone booking support.';
        break;
      case 'contact':
        title = 'Contact & Direct Location Map | Chambyal Dental Clinic Hamirpur';
        description =
          'Find contact numbers, clinic working hours, emergency lines, and our official Google Maps embed for easy directions to our clinic in Barsar near Main Bus Stand.';
        break;
      default:
        break;
    }

    // 2. Set DOM Title
    document.title = title;

    // 3. Update Meta tags dynamically
    const updateMetaTag = (attributeName: string, attributeValue: string, contentValue: string) => {
      let meta = document.querySelector(`meta[${attributeName}="${attributeValue}"]`);
      if (!meta) {
        meta = document.createElement('meta');
        meta.setAttribute(attributeName, attributeValue);
        document.head.appendChild(meta);
      }
      meta.setAttribute('content', contentValue);
    };

    updateMetaTag('name', 'description', description);
    
    // Open Graph Tags
    updateMetaTag('property', 'og:title', title);
    updateMetaTag('property', 'og:description', description);
    updateMetaTag('property', 'og:type', 'website');
    updateMetaTag('property', 'og:image', 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=1200');

    // 4. Inject Local Business & Dental Clinic Schema Markup
    const schemaId = 'chambyal-dental-schema';
    let scriptTag = document.getElementById(schemaId) as HTMLScriptElement;
    if (!scriptTag) {
      scriptTag = document.createElement('script');
      scriptTag.id = schemaId;
      scriptTag.type = 'application/ld+json';
      document.head.appendChild(scriptTag);
    }

    const schemaMarkup = {
      '@context': 'https://schema.org',
      '@graph': [
        {
          '@type': 'DentalClinic',
          '@id': 'https://chambyaldentalclinic.com/#clinic',
          'name': 'Chambyal Dental Clinic',
          'url': 'https://chambyaldentalclinic.com',
          'logo': 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=800',
          'image': 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=1200',
          'description': description,
          'telephone': '+919459778337',
          'priceRange': '₹₹',
          'address': {
            '@type': 'PostalAddress',
            'streetAddress': 'Chambyal Dental Clinic, Main Market Barsar, Near Bus Stand',
            'addressLocality': 'Barsar, Hamirpur',
            'addressRegion': 'Himachal Pradesh',
            'postalCode': '174305',
            'addressCountry': 'IN'
          },
          'geo': {
            '@type': 'GeoCoordinates',
            'latitude': '31.5714',
            'longitude': '76.4385'
          },
          'openingHoursSpecification': [
            {
              '@type': 'OpeningHoursSpecification',
              'dayOfWeek': ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'],
              'opens': '09:30',
              'closes': '18:30'
            }
          ],
          'sameAs': [
            'https://www.facebook.com/chambyaldentalclinic',
            'https://www.instagram.com/chambyaldentalclinic'
          ],
          'medicalSpecialty': 'Periodontics, Periodontology, Endodontics, Implantology, Orthodontics, CosmeticDentistry'
        },
        {
          '@type': 'Physician',
          '@id': 'https://chambyaldentalclinic.com/#doctor',
          'name': 'Dr. Ankush Chambyal',
          'image': 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=800',
          'medicalSpecialty': 'Dentist',
          'telephone': '+919459778337',
          'worksFor': {
            '@id': 'https://chambyaldentalclinic.com/#clinic'
          },
          'alumniOf': {
            '@type': 'EducationalOrganization',
            'name': 'Himachal Pradesh University & PG Dental Institutes'
          },
          'knowsAbout': [
            'Dental Implants',
            'Root Canal Treatment',
            'Smile Designing',
            'Microscopic Rotary Endodontics',
            'Porcelain Crowns and Veneers',
            'Full Mouth Oral Rehabilitation'
          ]
        }
      ]
    };

    scriptTag.text = JSON.stringify(schemaMarkup);

    return () => {
      // Cleanup is optional, but we keep the current page's script updated
    };
  }, [page]);

  return null;
}
