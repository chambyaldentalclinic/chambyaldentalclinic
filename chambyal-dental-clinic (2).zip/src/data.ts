import { DentalService, PatientReview, FAQItem, DoctorProfile, GalleryItem } from './types';
import implantsImg from './assets/images/regenerated_image_1780217459386.jpg';
import rctImg from './assets/images/regenerated_image_1780217461241.jpg';
import mdImg from './assets/images/regenerated_image_1780217462160.jpg';
import gumImg from './assets/images/regenerated_image_1780217464995.webp';
import pediatricImg from './assets/images/regenerated_image_1780216831877.jpg';
import ritikaImg from './assets/images/regenerated_image_1780217472503.jpg';
import orthodonticsImg from './assets/images/regenerated_image_1780220331956.webp';
import oralSurgeryImg from './assets/images/regenerated_image_1780220333279.jpg';
import partialDenturesImg from './assets/images/regenerated_image_1780220335023.webp';
import completeDenturesImg from './assets/images/regenerated_image_1780220336145.jpg';
import smileDesignImg from './assets/images/regenerated_image_1780220338298.jpg';
import whiteningImg from './assets/images/regenerated_image_1780220341980.jpg';
import crownsImg from './assets/images/regenerated_image_1780220343519.png';

export const servicesData: DentalService[] = [
  {
    id: 'implants',
    title: 'Dental Implants',
    shortDescription: 'Permanent, natural-looking replacement for missing teeth with advanced bio-compatible titanium.',
    description: 'Our state-of-the-art dental implant procedure offers a stable, lifelong solution for missing teeth. Using high-grade biocompatible titanium roots fused seamlessly with the jawbone, we craft customized crowns that mimic natural teeth in strength, appearance, and function.',
    benefits: [
      'Restores 100% chewing and speaking ability',
      'Prevents bone loss and maintains facial structure',
      'No slipping, sliding, or adjacent tooth damage',
      'Lifelong solution with proper oral hygiene'
    ],
    imageUrl: implantsImg,
    iconName: 'ShieldAlert'
  },
  {
    id: 'rct',
    title: 'Root Canal Treatment',
    shortDescription: 'Painless, tissue-saving root canal treatments to relieve pain and preserve your natural teeth.',
    description: 'Save your natural teeth with our advanced, painless root canal treatment (RCT). Using rotary endodontic technology and apex locators, we safely remove infected pulp tissue, thoroughly sterilize internal channels, and seal the canals with biocompatible materials to prevent future infection.',
    benefits: [
      'Completely painless procedure under local anesthesia',
      'Saves the natural tooth from extraction',
      'Eliminates persistent toothaches and hot/cold sensitivity',
      'Restores normal biting and mastication'
    ],
    imageUrl: rctImg,
    iconName: 'Activity'
  },
  {
    id: 'whitening',
    title: 'Teeth Whitening',
    shortDescription: 'Advanced clinical whitening systems that brighten your teeth up to 8 shades in a single session.',
    description: 'Transform stained, dull, or yellowed teeth into a dazzling bright look. Our clinic uses medical-grade dental lasers and gentle peroxide compounds to scrub deep pigments without causing tooth sensitivity or wear to your enamel.',
    benefits: [
      'Immediate, long-lasting whitening in just 45 minutes',
      'Safely removes stains from tea, coffee, smoking, and aging',
      'Individually customized chemical concentrations for minimal sensitivity',
      'Safe, professional alternative to abrasive over-the-counter kits'
    ],
    imageUrl: whiteningImg,
    iconName: 'Sparkles'
  },
  {
    id: 'smile-design',
    title: 'Smile Designing',
    shortDescription: 'Premium cosmetic dentistry to design your dream smile using digital mapping and porcelain veneers.',
    description: 'Ready for a total dynamic change? Our Smile Designing process integrates digital aesthetic planning, facial symmetry analysis, and customized ultra-thin porcelain veneers or composite bindings to correct gaps, chips, misalignment, and discolorations completely.',
    benefits: [
      'Fully customized smile layout designed to fit your unique facial features',
      'Uses digital preview technology before starting treatment',
      'Corrects multiple structural and visual flaws simultaneously',
      'Boosts professional and personal self-confidence instantly'
    ],
    imageUrl: smileDesignImg,
    iconName: 'Smile'
  },
  {
    id: 'crowns',
    title: 'Crowns and Bridges',
    shortDescription: 'Highly durable metal-free Zirconia and ceramic crowns to strengthen damaged teeth.',
    description: 'We offer premium, highly durable crown restorations using top-of-the-line materials like computer-designed Zirconia and E-max ceramic. Bridges offer custom-engineered anchorages to fill physical tooth voids, bridging the gaps with complete comfort.',
    benefits: [
      'Perfect color matching to your surrounding natural teeth',
      'Advanced computer-aided precision (CAD/CAM CAD design)',
      'Highly resistant to wear, fractures, and discoloration',
      'Bridges restore bite balance and prevent drifting teeth'
    ],
    imageUrl: crownsImg,
    iconName: 'Layers'
  },
  {
    id: 'complete-dentures',
    title: 'Complete Dentures',
    shortDescription: 'Comfortable, snug-fit full dentures designed for effortless chewing and natural facial support.',
    description: 'Regain your quality of life, youthful facial contours, and the joy of eating. Our custom full-denture arches are crafted using high-grade acrylic resins that seal snugly onto gums, ensuring natural pronunciation and strong structural chewing capacity.',
    benefits: [
      'Excellent suction and anatomical tissue-contour matching',
      'Restores hollowed-out cheeks and normal lip posture',
      'Lightweight materials selected for high comfort',
      'Shatter-resistant polymers built for long-term usage'
    ],
    imageUrl: completeDenturesImg,
    iconName: 'Heart'
  },
  {
    id: 'partial-dentures',
    title: 'Partial Dentures',
    shortDescription: 'Removable cast-metal or custom flexible dentures to seamlessly bridge scattered missing teeth.',
    description: 'Fill selective missing teeth gaps securely without needing complete extractions. We provide traditional acrylic partial dentures, cast-metal frameworks, and state-of-the-art flexible Valplast partials that are virtually invisible inside the mouth.',
    benefits: [
      'Flexible options prevent gum chafing and sores',
      'Clasped design ensures stable anchorage during meals',
      'Easy to remove, wash, and snap back into space',
      'Extremely economical and non-invasive procedure'
    ],
    imageUrl: partialDenturesImg,
    iconName: 'Grid'
  },
  {
    id: 'pediatric',
    title: 'Pediatric Dentistry',
    shortDescription: 'Gentle, painless kids dentistry in a friendly, fear-free environment focusing on healthy growth.',
    description: 'We love kids! Our pediatric dental care is tailored to be warm, interactive, and completely patient. From sealants that prevent early childhood cavities to gentle primary tooth fillings, we help build an early lifelong habits of positive oral hygiene.',
    benefits: [
      'Fun, child-friendly checkup methodologies',
      'Application of dental sealants and protective fluoride gels',
      'Early detection and guidance for proper jaw and tooth alignment',
      'Painless extractions for loose primary baby teeth'
    ],
    imageUrl: pediatricImg,
    iconName: 'Baby'
  },
  {
    id: 'gum-treatment',
    title: 'Gum Treatment',
    shortDescription: 'Advanced ultrasonic scaling and root planing to treat bleeding gums and prevent tooth loss.',
    description: 'Healthy teeth start with strong, healthy roots. We treat progressive stages of gingivitis and periodontitis using deep ultrasonic scaling, root planing, and local antibiotic irrigation, eliminating harmful bacterial plaques that lead to bone decay and bleeding gums.',
    benefits: [
      'Stopped gum bleeding, swelling, and persistent bad breath',
      'Deep detox of pockets underneath the outer gumline',
      'Strengthens loose support of teeth roots in the jawbone',
      'Lowers systemic inflammatory risks related to heart and diabetes'
    ],
    imageUrl: gumImg,
    iconName: 'Activity'
  },
  {
    id: 'oral-surgery',
    title: 'Oral Surgery',
    shortDescription: 'Expert surgical extractions, painless wisdom tooth removal, and localized trauma care.',
    description: 'Our clinic offers highly professional surgical support, including clean extractions of deeply impacted wisdom teeth, surgical root tips, cyst removals, and osseous preps, all performed under highly localized anesthetic blocks with minimal downtime.',
    benefits: [
      'Expert atraumatic removal of fully impacted painful teeth',
      'Advanced sterilization following rigorous clinical parameters',
      'Minimum bone trim for quick post-op healing',
      'Complete post-surgical follow-ups included for every patient'
    ],
    imageUrl: oralSurgeryImg,
    iconName: 'Scissors'
  },
  {
    id: 'orthodontics',
    title: 'Braces and Orthodontics',
    shortDescription: 'Metal, ceramic, and advanced invisible aligners to correct crooked teeth and bad bites.',
    description: 'Achieve perfectly straight teeth and optimal bite balance. We offer full orthodontic plans utilizing traditional durable metal braces, tooth-colored clear ceramic braces, and modern modern clear invisible aligners for kids, teenagers, and working professionals.',
    benefits: [
      'Corrects crowded, spaced, or protruding teeth',
      'Resolves jaw joint strain (TMJ issues) and chewing mismatches',
      'Aesthetic, transparent ceramic or aligner alternatives',
      'Customized post-braces retainer plan to secure your ideal smile'
    ],
    imageUrl: orthodonticsImg,
    iconName: 'Grid3X3'
  },
  {
    id: 'preventive',
    title: 'Preventive Dental Care',
    shortDescription: 'Regular professional scaling, cavity protection coatings, and oral health checkups.',
    description: 'An ounce of prevention is worth a pound of cure. Prevent complex dental diseases with our biannual preventive evaluations, comprising active clinical examinations, micro-scaling, dental sealants, oral screening, and dietary guidance for strong teeth.',
    benefits: [
      'Stops dental problems early before they require costly treatment',
      'Polishes and eliminates deep tar and tobacco stains',
      'Includes dental wellness coaching and personalized routine plans',
      'Zero discomfort session to maintain sparkling white teeth'
    ],
    imageUrl: 'https://images.unsplash.com/photo-1606811971618-4486d14f3f99?auto=format&fit=crop&q=80&w=600',
    iconName: 'HeartHandshake'
  }
];

export const doctorProfile: DoctorProfile = {
  name: 'Dr. Ankush Chambyal',
  title: 'Founder & Chief Implantologist',
  degrees: ['BDS (Bachelor of Dental Surgery)', 'MDS (Periodontology and Oral Implantology)', 'Fellowship in Implantology (IAECD)'],
  specializations: [
    'Advanced Periodontal Therapy & Surgery',
    'Advanced Oral Implantology',
    'Full Mouth Cosmetic Rehabilitation',
    'Smile Designing & Esthetic Treatments'
  ],
  experienceYears: 11,
  biography: [
    'I am Dr. Ankush Chambyal, MDS in Periodontology and Oral Implantology, with a Fellowship in Implantology by IAECD, dedicated to providing comprehensive dental care with a focus on precision, comfort, and long-term oral health. With over 11 years of clinical experience, I have had the privilege of helping thousands of patients achieve healthier smiles and improved confidence through advanced dental treatments.',
    'My expertise encompasses dental implants, periodontal (gum) therapy, cosmetic dentistry, smile rehabilitation, preventive dental care, and advanced surgical procedures. I believe that every patient deserves individualized treatment, and I strive to create a comfortable and welcoming environment where patients feel informed, valued, and confident about their dental care decisions.',
    'At Chambyal Dental Clinic, we combine modern technology, evidence-based treatment protocols, and the highest standards of sterilization to deliver safe, effective, and painless dental solutions. My commitment to continuous learning and professional excellence ensures that patients receive the latest and most advanced treatment options available in modern dentistry.',
    'Whether you require routine dental care, a complete smile makeover, or advanced implant therapy, my goal is to provide exceptional treatment outcomes while building lasting relationships based on trust, integrity, and patient satisfaction.'
  ],
  treatmentPhilosophy: '“Your smile is our priority, and your oral health is our passion.”',
  achievements: [
    'MDS in Periodontology & Oral Implantology with Distinguished Honors',
    'Fellowship in Implantology by Indian Academy of Esthetic & Cosmetic Dentistry (IAECD)',
    'Recipient of the "Best Dentist of the Year" Award in Hamirpur District (2024)',
    'Active Fellow of the International Congress of Oral Implantologists (ICOI, USA)',
    'Pioneered Advanced Microscopic Surgical & Implant procedures in the Hamirpur-Barsar region'
  ],
  imageUrl: '/dr-ankush-chambyal.jpg'
};

export const doctorsData: DoctorProfile[] = [
  {
    name: 'Dr. Ankush Chambyal',
    title: 'Founder & Chief Implantologist',
    degrees: ['BDS (Bachelor of Dental Surgery)', 'MDS (Periodontology and Oral Implantology)', 'Fellowship in Implantology (IAECD)'],
    specializations: [
      'Advanced Periodontal Therapy & Surgery',
      'Advanced Oral Implantology',
      'Full Mouth Cosmetic Rehabilitation',
      'Smile Designing & Esthetic Treatments'
    ],
    experienceYears: 11,
    biography: [
      'I am Dr. Ankush Chambyal, MDS in Periodontology and Oral Implantology, with a Fellowship in Implantology by IAECD, dedicated to providing comprehensive dental care with a focus on precision, comfort, and long-term oral health. With over 11 years of clinical experience, I have had the privilege of helping thousands of patients achieve healthier smiles and improved confidence through advanced dental treatments.',
      'My expertise encompasses dental implants, periodontal (gum) therapy, cosmetic dentistry, smile rehabilitation, preventive dental care, and advanced surgical procedures. I believe that every patient deserves individualized treatment, and I strive to create a comfortable and welcoming environment where patients feel informed, valued, and confident about their dental care decisions.',
      'At Chambyal Dental Clinic, we combine modern technology, evidence-based treatment protocols, and the highest standards of sterilization to deliver safe, effective, and painless dental solutions. My commitment to continuous learning and professional excellence ensures that patients receive the latest and most advanced treatment options available in modern dentistry.',
      'Whether you require routine dental care, a complete smile makeover, or advanced implant therapy, my goal is to provide exceptional treatment outcomes while building lasting relationships based on trust, integrity, and patient satisfaction.'
    ],
    treatmentPhilosophy: '“Your smile is our priority, and your oral health is our passion.”',
    achievements: [
      'MDS in Periodontology & Oral Implantology with Distinguished Honors',
      'Fellowship in Implantology by Indian Academy of Esthetic & Cosmetic Dentistry (IAECD)',
      'Awarded "Best Dentist of the Year" in Hamirpur (2024)',
      'Active Fellow of the International Congress of Oral Implantologists (ICOI, USA)',
      'First to introduce Microscopic Implantology & Periodontics in Barsar and nearby regions'
    ],
    imageUrl: '/dr-ankush-chambyal.jpg'
  },
  {
    name: 'Dr. Ritika Chambyal',
    title: 'RCT Expert & Micro Dentistry Specialist',
    degrees: ['BDS (Bachelor of Dental Surgery)', 'Fellowship in Implantology by IAECD'],
    specializations: [
      'Single-Visit Painless Root Canals (RCT)',
      'Advanced Micro-Dentistry & Magnification',
      'Cosmetic Composite Smile Restorations',
      'Pediatric & Preventive Dental Care'
    ],
    experienceYears: 7,
    biography: [
      'Dr. Ritika, BDS is a highly skilled and compassionate dental professional with over 7 years of clinical experience in providing comprehensive dental care. She is particularly known for her expertise in Root Canal Treatment (RCT) and is committed to preserving natural teeth through precise, painless, and effective endodontic procedures.',
      'With a patient-centered approach, Dr. Ritika believes in delivering treatment with the utmost care, comfort, and attention to detail. Her clinical expertise extends across restorative dentistry, preventive dental care, cosmetic procedures, and management of dental pain and infections. She is dedicated to helping patients achieve optimal oral health while ensuring a stress-free and comfortable dental experience.',
      'At Chambyal Dental Clinic, Dr. Ritika utilizes modern techniques and advanced equipment to provide high-quality dental treatments tailored to the individual needs of each patient. Her gentle chairside manner, commitment to excellence, and focus on patient education have earned the trust and appreciation of numerous patients over the years.',
      'Whether it is a routine dental check-up, a complex root canal procedure, or restorative treatment, Dr. Ritika strives to deliver exceptional results while maintaining the highest standards of professionalism and patient care.'
    ],
    treatmentPhilosophy: '“Dedicated to saving natural teeth, relieving pain, and creating healthy, confident smiles.”',
    achievements: [
      'Certified Practitioner in Advanced Pediatric Conscious Sedation & Comfort Management',
      'Distinguished Consultant on Microscopic Endodontics & Painless Odontia',
      'Active Contributor to HP Oral Health Advancement Programs'
    ],
    imageUrl: ritikaImg
  },
  {
    name: 'Mr. Amarjit Singh',
    title: 'Managing Director & Prophylaxis Care Pioneer',
    degrees: ['Dental Hygienist (DH) Course - AFMC, Pune', 'Registered Healthcare Director'],
    specializations: [
      'Comprehensive Treatment Coordination',
      'Clinical Protocol & Sterilization Excellence',
      'Community Dental Health Prophylaxis',
      'Patient Advocate & Quality Assurance'
    ],
    experienceYears: 40,
    biography: [
      'Mr. Amarjit Singh is the Managing Director of Chambyal Dental Clinic and a respected healthcare professional with more than 40 years of experience in the field of dental healthcare and patient services. He completed his Dental Hygienist (DH) Course from Armed Forces Medical College (AFMC), Pune, one of India\'s most prestigious medical institutions.',
      'Throughout his distinguished career, Mr. Singh has been committed to promoting oral health awareness, patient care, and excellence in dental services. His vast experience, leadership, and dedication have played a pivotal role in establishing Chambyal Dental Clinic as a trusted destination for quality dental treatment and compassionate patient care.',
      'Known for his integrity, professionalism, and patient-first approach, Mr. Singh has guided the clinic with a vision of combining advanced dental technology with ethical and personalized treatment. His commitment to maintaining the highest standards of healthcare has earned the confidence and trust of countless patients over the decades.',
      'As the driving force behind Chambyal Dental Clinic, he continues to inspire a culture of excellence, ensuring that every patient receives exceptional care in a comfortable and welcoming environment.',
      'With four decades of experience, dedication, and service, Mr. Amarjit Singh remains committed to improving smiles and enhancing the oral health of the community.'
    ],
    treatmentPhilosophy: '“With four decades of experience, dedication, and service, Mr. Amarjit Singh remains committed to improving smiles and enhancing the oral health of the community.”',
    achievements: [
      'Alumnus of the prestigious Armed Forces Medical College (AFMC), Pune',
      'Over 40 Years of Inspiring Leadership & Dental Health Administration',
      'Pioneer of Community Preventive Programs & Patient Support Services'
    ],
    imageUrl: mdImg
  }
];

export const reviewsData: PatientReview[] = [
  {
    id: 'rev-1',
    authorName: 'Suresh Sharma',
    reviewDate: '2 Weeks ago',
    rating: 5,
    comment: 'Best dental clinic in Barsar and nearby regions of Hamirpur! I got my dental implants done by Dr. Ankush Chambyal. The process was completely painless, and the staff was extremely professional. Highly recommended!',
    verified: true
  },
  {
    id: 'rev-2',
    authorName: 'Meenakshi Devi',
    reviewDate: '1 Month ago',
    rating: 5,
    comment: 'I visited for root canal treatment (RCT). I was very scared of pain, but Dr. Ankush handled it so gently. The modern machines he used made the whole process quick and painless. The sterilization is top notch.',
    verified: true
  },
  {
    id: 'rev-3',
    authorName: 'Rajesh Kumar Kudhu',
    reviewDate: '2 Months ago',
    rating: 5,
    comment: 'Very clean clinic, polite behavior and affordable pricing. They explained the cost and treatment fully before starting. Best dentist in Hamirpur district without a doubt.',
    verified: true
  },
  {
    id: 'rev-4',
    authorName: 'Anshul Patial',
    reviewDate: '3 Months ago',
    rating: 5,
    comment: 'Got my smile designing with ceramic crowns done here. Amazing transformation. My friends say my teeth look so natural and bright now. Thank you Chambyal Dental Clinic!',
    verified: true
  },
  {
    id: 'rev-5',
    authorName: 'Jyoti Thakur',
    reviewDate: '4 Months ago',
    rating: 5,
    comment: 'Highly professional pediatric dentist. Brought my 6-year-old son for cavity treatment. The clinic has a nice calming environment, and child was handled with so much love. He did not cry at all!',
    verified: true
  }
];

export const faqsData: FAQItem[] = [
  {
    id: 'faq-1',
    question: 'How much do dental implants cost at Chambyal Dental Clinic?',
    answer: 'The cost of dental implants depends on the brand of biological titanium implant (Korean, German, or USA-made) and the type of prosthetic crown selected (Ceramic or metal-free Zirconia). We offer customized, cost-effective dental implant structures with flexible payment plans. Book a consultation for a detailed checkup and quote.',
    category: 'implants'
  },
  {
    id: 'faq-2',
    question: 'Is Root Canal Treatment (RCT) painful?',
    answer: 'At Chambyal Dental Clinic, root canals are virtually painless. We utilize modern single-session rotary endodontics and highly effective localized anesthesia. Most patients report it is no more uncomfortable than receiving a standard filling.',
    category: 'general'
  },
  {
    id: 'faq-3',
    question: 'What are the clinic working hours?',
    answer: 'Chambyal Dental Clinic is open from Monday to Saturday, 9:30 AM to 6:30 PM. We are closed on Sundays, except for pre-scheduled surgical procedures and emergency dental trauma cases.',
    category: 'general'
  },
  {
    id: 'faq-4',
    question: 'How often should I visit Chambyal Dental Clinic for a dental cleaning?',
    answer: 'We recommend visiting us once every 6 months for a routine preventive scaling and clinical evaluation. This effectively removes hard tartar blocks, prevents gum bleeding, and detects cavities when they are simple and cheap to resolve.',
    category: 'preventive'
  },
  {
    id: 'faq-5',
    question: 'Are dental materials and crowns certified?',
    answer: 'Yes! We only use ISO-certified, FDA-approved biocompatible dental crowns, implants, and composite fillings. Every Zirconia crown comes with an official warranty certificate of 10 to 15 years.',
    category: 'implants'
  },
  {
    id: 'faq-6',
    question: 'How do I book an emergency extraction or toothache appointment?',
    answer: 'For emergency toothaches or traumas, you can call us directly on our mobile number or click the floating WhatsApp button. We prioritize pain-relief emergency bookings immediately to relieve discomfort same-day.',
    category: 'general'
  }
];

export const galleryData: GalleryItem[] = [
  {
    id: 'gal-1',
    title: 'Clinic Reception and Waiting Area',
    category: 'interior',
    imageUrl: 'https://images.unsplash.com/photo-1629909613654-28e377c37b09?auto=format&fit=crop&q=80&w=800',
    description: 'Our luxurious high-contrast waiting lounge designed for maximum patient comfort.'
  },
  {
    id: 'gal-2',
    title: 'Ultra-Modern Dental Treatment Suite',
    category: 'treatment',
    imageUrl: 'https://images.unsplash.com/photo-1579684389782-64d84b5e9053?auto=format&fit=crop&q=80&w=800',
    description: 'Fully automated medical dental chair equipped with soft pressure contouring and LED surgical lights.'
  },
  {
    id: 'gal-3',
    title: 'Autoclave & Class-B Sterilization Lab',
    category: 'equipment',
    imageUrl: 'https://images.unsplash.com/photo-1513412893-4e4ad1b835e2?auto=format&fit=crop&q=80&w=800',
    description: 'Strict sterilization room featuring clean vacuum steam autoclaves following European parameters.'
  },
  {
    id: 'gal-4',
    title: 'Smile Rejuvenation (Full Arch)',
    category: 'transformation',
    imageUrl: 'https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&q=80&w=800',
    description: 'Full Smile Transformation using custom metal-free E-Max veneers restoring natural brightness.'
  },
  {
    id: 'gal-5',
    title: 'Premium Dental CAD/CAM Scanner',
    category: 'equipment',
    imageUrl: 'https://images.unsplash.com/photo-1468495244123-6c6c332eeece?auto=format&fit=crop&q=80&w=800',
    description: 'Digital 3D intraoral scanner that captures ultra-high resolution dental impressions in seconds.'
  },
  {
    id: 'gal-6',
    title: 'Esthetic Veneer Preparation',
    category: 'transformation',
    imageUrl: 'https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&q=80&w=800',
    description: 'Cosmetic alignment correcting gaps and discolored lateral teeth elements.'
  }
];
