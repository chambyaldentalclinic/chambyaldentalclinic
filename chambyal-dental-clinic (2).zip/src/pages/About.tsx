import { ShieldCheck, Heart, Sparkles, Award, Eye, Compass, FlaskConical } from 'lucide-react';
import { motion } from 'motion/react';

import introImg from '../assets/images/regenerated_image_1780220749824.jpg';
import techImg from '../assets/images/regenerated_image_1780220751904.jpg';

export default function About() {
  const values = [
    {
      title: 'Our Clinic Mission',
      desc: 'To deliver premium dental solutions, specialized implant surgery, and gentle family dentistry to Himachal Pradesh, combining affordability with active clinical excellence.',
      icon: Compass
    },
    {
      title: 'Our Vision Parameters',
      desc: 'To establish Chambyal Dental Clinic as the undisputed state leader for advanced microscopic endodontics and painless digital restorations, saving native teeth roots.',
      icon: Eye
    },
    {
      title: 'Patient-First Philosophy',
      desc: 'Every check-up gets our undivided focus. We spend time detailing dental diagnostics first, clarifying budgets, and guaranteeing maximum comfort throughout therapy.',
      icon: Heart
    }
  ];

  const protocols = [
    {
      title: 'Vacuum Class-B Autoclave sterilization',
      details: 'All diagnostic tips, elevators, tweezers, and dental burs undergo double-cycle steam autoclave baking under absolute vacuum pressure to eradicate 100% of bacterial spores and viral elements.'
    },
    {
      title: 'Multi-Barrier Disposable Protectors',
      details: 'Every patient is fitted with single-use sterile sheets, protective glasses, disposable saliva suction tips, and dental syringes to negate any possibilities of viral cross-contamination.'
    },
    {
      title: 'Continuous Waterline Cleansing',
      details: 'Operating chairs utilize pure, mineral-filtered reverse osmosis (RO) water pathways treated daily with silver-ion sanitation tablets, guaranteeing pristine clean oral spray.'
    }
  ];

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#F8FAFC] py-16 min-h-screen"
      id="about-us-page-render"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Page title header */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <span className="text-[#0F4C81] text-xs font-bold uppercase tracking-widest block">Establishing Clinical Competence</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            About Chambyal Dental Clinic
          </h1>
          <p className="text-slate-600 text-sm sm:text-base leading-relaxed">
            Founded with the belief that premium dental restorations and surgical implants should be accessible to everyone in Hamirpur, Barsar, and nearby communities.
          </p>
        </div>

        {/* Introduction Section with Image */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center mb-24">
          <div className="lg:col-span-6 space-y-6">
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-950 tracking-tight">
              A New Standard in Regional Oral Healthcare
            </h2>
            <div className="w-16 h-1 bg-[#20B2AA] rounded-full"></div>
            <p className="text-slate-700 text-sm leading-relaxed">
              Nestled at the heart of Barsar, Hamirpur, Chambyal Dental Clinic redefines traditional dental visits into comfort-driven dental experiences. Established by veteran surgeon Dr. Ankush Chambyal, our dental hospital houses the finest equipment designed specifically for modern painless endodontics.
            </p>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              Instead of forcing generic, mass-produced crowns or hasty extractions, we use computer-aided 3D scanner meshes and premium biocompatible titanium implants that fuse harmlessly back into the native jaw bone. We are proud promoters of sustainable, biological tooth saving.
            </p>
          </div>
          <div className="lg:col-span-6">
            <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
              <img
                src={introImg}
                alt="Chambyal Dental Clinic Hygiene Suite"
                referrerPolicy="no-referrer"
                className="w-full h-[360px] object-cover"
              />
            </div>
          </div>
        </section>


        {/* Mission, Vision, and Philosphy Bento */}
        <section className="mb-24">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {values.map((v, idx) => {
              const IconComp = v.icon;
              return (
                <div key={idx} className="bg-white p-8 rounded-3xl border border-slate-150 shadow-lg relative overflow-hidden group">
                  <div className="absolute top-0 left-0 w-full h-1 bg-[#0F4C81] opacity-0 group-hover:opacity-100 transition-all duration-300"></div>
                  <div className="w-12 h-12 rounded-2xl bg-[#0F4C81]/10 text-[#0F4C81] flex items-center justify-center mb-6">
                    <IconComp className="w-6 h-6" />
                  </div>
                  <h3 className="text-lg font-bold text-slate-950 tracking-tight mb-3">{v.title}</h3>
                  <p className="text-slate-500 text-xs leading-relaxed">{v.desc}</p>
                </div>
              );
            })}
          </div>
        </section>


        {/* Sterilization and Hygiene Protocols */}
        <section className="bg-slate-900 text-white rounded-3xl p-8 sm:p-12 md:p-16 mb-24 shadow-2xl">
          <div className="max-w-3xl space-y-4 mb-12">
            <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest block flex items-center gap-2">
              <ShieldCheck className="w-4.5 h-4.5" /> Hygiene First parameter
            </span>
            <h2 className="text-3xl font-extrabold tracking-tight">NHS & European Standard Sterilization Lab</h2>
            <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
              Our absolute top priority is clinical safety. Dr. Ankush supervises a three-tier infection barrier control process daily, guaranteeing that every surgical tool is 100% free of microbes.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {protocols.map((prot, idx) => (
              <div key={idx} className="space-y-3 bg-white/5 border border-white/10 p-6 rounded-2xl">
                <div className="w-8 h-8 rounded-full bg-[#20B2AA]/20 text-[#20B2AA] flex items-center justify-center text-xs font-bold font-mono">
                  {idx + 1}
                </div>
                <h4 className="text-base font-bold text-white tracking-tight">{prot.title}</h4>
                <p className="text-slate-400 text-xs leading-relaxed">{prot.details}</p>
              </div>
            ))}
          </div>
        </section>


        {/* Modern Equipment and Technology list */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center mb-24">
          <div className="lg:col-span-6 relative order-last">
            <img
              src={techImg}
              alt="Advanced Digital Scanning and CAD designing Tools at Clinic"
              referrerPolicy="no-referrer"
              className="rounded-3xl shadow-xl w-full h-[380px] object-cover"
            />
          </div>
          <div className="lg:col-span-6 space-y-6">
            <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest block">Futuristic Diagnostics</span>
            <h2 className="text-2xl sm:text-3xl font-extrabold text-slate-900 tracking-tight">Modern Equipment & Technologies</h2>
            <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
              We update our operatories regularly with cutting-edge dental machines, reducing patient discomfort, cutting chair-time by 50%, and preventing repeat root appointments.
            </p>

            <ul className="space-y-3">
              {[
                { label: 'Intraoral 3D CAM Scanners', desc: 'Saves digital dental mappings without using sticky uncomfortable moulding muds.' },
                { label: 'Rotary Dental Endosystems', desc: 'Makes saving tooth roots highly rapid, sterile, and pain-free with computer-guided torque.' },
                { label: 'Zero-Radiation Digital Radiographs', desc: 'Instants crystal-clear X-Ray scans safely on monitor, exposing patients to 90% less radiation.' },
                { label: 'High Density Ultrasonic Scalers', desc: 'Detoxes roots and deep pockets via comfortable ultrasonic micro-waves.' }
              ].map((eq, i) => (
                <li key={i} className="flex gap-3">
                  <div className="w-5 h-5 rounded-full bg-emerald-100 flex items-center justify-center shrink-0 mt-0.5">
                    <span className="text-emerald-700 text-[10px] font-extrabold">✓</span>
                  </div>
                  <div>
                    <h5 className="font-bold text-xs sm:text-sm text-slate-950">{eq.label}</h5>
                    <p className="text-xs text-slate-500 mt-0.5">{eq.desc}</p>
                  </div>
                </li>
              ))}
            </ul>
          </div>
        </section>


        {/* Certifications and Achievements CTA */}
        <section className="p-8 sm:p-12 bg-white rounded-3xl border border-slate-150 shadow-xl flex flex-col md:flex-row items-center gap-8 justify-between relative overflow-hidden">
          <div className="space-y-2">
            <span className="text-[#0F4C81] text-xs font-bold uppercase tracking-widest block flex items-center gap-1.5">
              <Award className="w-4 h-4 text-[#20B2AA]" /> Accredited Clinicians HP
            </span>
            <h3 className="text-2xl font-extrabold text-slate-900 tracking-tight">Licensed & Affiliated Under State Dental Councils</h3>
            <p className="text-slate-500 text-xs sm:text-sm leading-relaxed max-w-2xl">
              Chambyal Dental Clinic maintains active certifications under HP State Dental Councils and ISO quality assurance metrics, proving our persistent dedication to premium care limits.
            </p>
          </div>
          <div className="w-full sm:w-auto shrink-0 flex items-center gap-3 bg-slate-50 p-4 border border-slate-200 rounded-2xl">
            <span className="font-extrabold text-[#0F4C81] text-3xl">12+</span>
            <span className="text-xs text-slate-600 font-bold leading-normal">Years of Clinical Excellence</span>
          </div>
        </section>

      </div>
    </motion.div>
  );
}
