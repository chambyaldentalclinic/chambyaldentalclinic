import AppointmentForm from '../components/AppointmentForm';
import { Clock, ShieldAlert, Heart, Phone } from 'lucide-react';
import { motion } from 'motion/react';

interface BookingPageProps {
  selectedTreatment: string;
  setSelectedTreatment: (treatment: string) => void;
}

export default function BookingPage({ selectedTreatment, setSelectedTreatment }: BookingPageProps) {
  const clinicPhone = '+919459778337';

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#F8FAFC] py-16 min-h-screen"
      id="booking-root-page"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title details */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-[#0F4C81] text-xs font-bold uppercase tracking-widest block font-mono">Secured Online Scheduling</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Book Your Dental Appointment
          </h1>
          <p className="text-slate-600 text-sm leading-relaxed">
            Reserve your consultation slot with Dr. Ankush Chambyal. Instant digital queue updates will be sent to your mobile phone number.
          </p>
        </div>

        {/* Outer Split row */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start">
          
          {/* Left Block: Helpful Patient Booking Guidelines */}
          <div className="lg:col-span-4 space-y-8 lg:sticky lg:top-24">
            
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-150 shadow-md space-y-6">
              
              <div className="space-y-2">
                <h3 className="text-base font-extrabold text-[#0F4C81] uppercase tracking-wide">Scheduling Guidelines</h3>
                <p className="text-xs text-slate-500 leading-normal">
                  Our clinic strictly complies with hygiene parameters. To minimize overcrowding and guarantee zero contamination:
                </p>
              </div>

              <div className="space-y-4 font-semibold text-slate-700 text-xs sm:text-sm">
                
                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-teal-50 text-[#20B2AA] flex items-center justify-center shrink-0">
                    <Clock className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-slate-900 font-bold text-xs sm:text-sm">Arrive 10 Mins Prior</h4>
                    <p className="text-[11px] text-slate-500 font-medium mt-0.5">Allows quick digital registration and bio-cleansing preps.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-emerald-50 text-emerald-600 flex items-center justify-center shrink-0">
                    <Heart className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-slate-900 font-bold text-xs sm:text-sm">Free Rescheduling</h4>
                    <p className="text-[11px] text-slate-500 font-medium mt-0.5">Change slots easily from your WhatsApp confirmation link anytime.</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-8 h-8 rounded-lg bg-amber-50 text-amber-600 flex items-center justify-center shrink-0">
                    <ShieldAlert className="w-4 h-4" />
                  </div>
                  <div>
                    <h4 className="text-slate-900 font-bold text-xs sm:text-sm">Pain Emergencies Priority</h4>
                    <p className="text-[11px] text-slate-500 font-medium mt-0.5">Acute severe tooth traumas/bleeding bypass the online queue lines.</p>
                  </div>
                </div>

              </div>

            </div>

            {/* Direct Dial Emergency Box */}
            <div className="p-6 bg-slate-950 text-white rounded-3xl border border-slate-900 text-center space-y-4 shadow-xl">
              <h4 className="text-sm font-extrabold text-teal-400 uppercase tracking-widest leading-none">In Pain? Dial Directly</h4>
              <p className="text-slate-400 text-xs leading-normal">
                Speak directly with Dr. Ankush in case of accidents, dislocated crowns, or deep nerve swelling.
              </p>
              <a
                href={`tel:${clinicPhone}`}
                className="inline-flex items-center gap-2 px-5 py-2.5 bg-rose-600 hover:bg-rose-700 text-white font-bold rounded-lg text-xs tracking-wider uppercase transition-colors"
              >
                <Phone className="w-4 h-4 fill-current text-white animate-pulse" />
                <span>Call +91 94597 78337</span>
              </a>
            </div>

          </div>

          {/* Right Column: Dynamic appointment form container */}
          <div className="lg:col-span-8">
            <AppointmentForm 
              initialTreatmentId={selectedTreatment} 
              onSuccessClose={() => setSelectedTreatment('')} 
            />
          </div>

        </div>

      </div>
    </motion.div>
  );
}
