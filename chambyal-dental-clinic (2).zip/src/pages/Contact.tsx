import React, { useState } from 'react';
import { 
  MapPin, 
  Phone, 
  Mail, 
  Clock, 
  ShieldAlert, 
  CheckCircle,
  ExternalLink, 
  MessageSquare 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function Contact() {
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [email, setEmail] = useState('');
  const [massage, setMassage] = useState('');
  const [isSubmitSuccess, setIsSubmitSuccess] = useState(false);
  const [errorText, setErrorText] = useState('');

  const clinicPhone = '+919459778337';
  const clinicPhone2 = '+919418366088';
  const clinicEmail = 'ankushchambyal@gmail.com';
  const clinicAddressStr = 'Chambyal Dental Clinic, Main Market Barsar, Near Bus Stand, Barsar, Hamirpur, Himachal Pradesh - 174305';
  
  const handleContactSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setErrorText('');

    if (!name.trim()) {
      setErrorText('Please specify your name first.');
      return;
    }
    const phonePattern = /^[6-9]\d{9}$/;
    if (!phone || !phonePattern.test(phone.replace(/\s+/g, ''))) {
      setErrorText('Please input a valid 10-digit primary mobile number.');
      return;
    }

    setIsSubmitSuccess(true);
    // Persist local message
    const localMessage = {
      name,
      phone,
      email,
      massage,
      timestamp: new Date().toISOString()
    };
    const prevMsgs = JSON.parse(localStorage.getItem('chambyal_dental_messages') || '[]');
    localStorage.setItem('chambyal_dental_messages', JSON.stringify([...prevMsgs, localMessage]));
  };

  const handleResetSuccess = () => {
    setName('');
    setPhone('');
    setEmail('');
    setMassage('');
    setIsSubmitSuccess(false);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#F8FAFC] py-16 min-h-screen"
      id="contact-page-root"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title sections */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-20">
          <span className="text-[#0F4C81] text-xs font-bold uppercase tracking-widest block font-mono">Immediate Local Assistance</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Connect With Our Clinic
          </h1>
          <p className="text-slate-600 text-sm leading-relaxed">
            Have questions about clinical costs, root canals, or want to Tour our sterilized suites? Contact Dr. Ankush Chambyal's team now.
          </p>
        </div>

        {/* Contact info cards row */}
        <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          
          {/* Phone */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-150 shadow-md space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-blue-50 text-[#0F4C81] flex items-center justify-center">
                <Phone className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-950">Phone Assistance</h3>
              <p className="text-slate-500 text-xs">Speak with our desk executive for quick bookings.</p>
            </div>
            <div className="pt-2 text-sm font-bold text-[#0F4C81] space-y-1">
              <a href={`tel:${clinicPhone}`} className="hover:underline block">
                +91 94597 78337
              </a>
              <a href={`tel:${clinicPhone2}`} className="hover:underline block">
                +91 94183 66088
              </a>
            </div>
          </div>

          {/* Email */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-150 shadow-md space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-teal-50 text-[#20B2AA] flex items-center justify-center">
                <Mail className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-950">Official Email</h3>
              <p className="text-slate-500 text-xs">For clinical partnerships or medical claims queries.</p>
            </div>
            <a href={`mailto:${clinicEmail}`} className="text-sm font-bold text-slate-700 hover:underline block pt-2 truncate leading-tight">
              {clinicEmail}
            </a>
          </div>

          {/* Core Hours */}
          <div className="bg-white p-6 sm:p-8 rounded-3xl border border-slate-150 shadow-md space-y-4 flex flex-col justify-between">
            <div className="space-y-3">
              <div className="w-10 h-10 rounded-xl bg-indigo-50 text-indigo-700 flex items-center justify-center">
                <Clock className="w-5 h-5" />
              </div>
              <h3 className="text-base font-extrabold text-slate-950">Operating Hours</h3>
              <p className="text-slate-500 text-xs">Standard operating hours.</p>
            </div>
            <div className="text-xs font-bold text-slate-700 space-y-0.5 leading-none pt-2">
              <p>Mon - Sat: 09:30 AM - 06:30 PM</p>
              <p className="text-rose-500 mt-1 !text-[10px] uppercase">Sunday Closed</p>
            </div>
          </div>

          {/* Emergency support */}
          <div className="bg-slate-950 text-white p-6 sm:p-8 rounded-3xl border border-slate-900 shadow-xl space-y-4 flex flex-col justify-between">
            <div className="space-y-2">
              <div className="w-10 h-10 rounded-xl bg-rose-500/10 text-rose-400 flex items-center justify-center">
                <ShieldAlert className="w-5 h-5" />
              </div>
              <h3 className="text-base font-bold text-white tracking-tight leading-snug">Emergency Trauma lines</h3>
              <p className="text-slate-400 text-xs">Open 24/7 for dental trauma or acute severe pain checks.</p>
            </div>
            <div className="text-xs font-extrabold text-rose-400 tracking-wider uppercase block space-y-1">
              <a href={`tel:${clinicPhone}`} className="hover:underline block">
                Call: +91 94597 78337
              </a>
              <a href={`tel:${clinicPhone2}`} className="hover:underline block">
                Call: +91 94183 66088
              </a>
            </div>
          </div>

        </section>


        {/* Form and Maps Embed side-by-side splits */}
        <section className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-start mb-24">
          
          {/* Left Split: Google Map direction Card */}
          <div className="lg:col-span-6 space-y-8">
            <div className="bg-white rounded-3xl p-6 sm:p-8 border border-slate-150 shadow-lg space-y-6">
              
              <div className="space-y-2">
                <h2 className="text-xl font-extrabold text-slate-900 tracking-tight flex items-center gap-2">
                  <MapPin className="w-5 h-5 text-[#20B2AA]" /> Find Us on Google Maps
                </h2>
                <p className="text-slate-500 text-[11px] font-semibold leading-normal">
                  Chambyal Dental Clinic is located directly next to the Barsar Main Market corridor, in close walking limits of the regional Bus Stand for client comfort.
                </p>
              </div>

              {/* Requirements Maps PLACEHOLDER iframe */}
              <div className="relative h-[280px] w-full rounded-2xl overflow-hidden border border-slate-100 shadow-sm">
                <iframe 
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3419.6455113945!2d76.4385!3d31.5714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzHCsDM0JzE3LjAiTiA3NisyNicyOC42IkU!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
                  title="Official Chambyal Dental Clinic Location Embed Outline"
                  className="absolute inset-0 w-full h-full border-0" 
                  allowFullScreen={true}
                  loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade"
                ></iframe>
              </div>

              {/* Requirement deep connection buttons */}
              <div className="flex flex-col sm:flex-row gap-3 pt-2">
                <a
                  href="https://maps.app.goo.gl/BoWTSAnezZBmPDXF8"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="flex-1 px-5 py-3 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 shadow"
                  id="btn-trigger-maps-directions"
                >
                  <MapPin className="w-4 h-4 text-teal-400" />
                  <span>Get Driving Directions</span>
                </a>
                <a
                  href={`tel:${clinicPhone}`}
                  className="flex-1 px-5 py-3 bg-slate-50 border border-slate-200 hover:bg-slate-100 text-slate-800 font-bold text-xs rounded-xl flex items-center justify-center gap-2"
                >
                  <Phone className="w-4 h-4 text-slate-500" />
                  <span>Call Clinic Support</span>
                </a>
              </div>

            </div>
          </div>


          {/* Right Split: Contact Message Form */}
          <div className="lg:col-span-6">
            <div className="bg-white rounded-3xl p-6 sm:p-10 border border-slate-150 shadow-lg relative overflow-hidden" id="interactive-contact-form-box">
              <div className="absolute top-0 left-0 w-full h-1 bg-[#20B2AA]"></div>
              
              <div className="mb-6">
                <h3 className="text-xl font-bold text-slate-950 tracking-tight">Drop Us a message</h3>
                <p className="text-xs text-slate-500 mt-1">
                  Fill in your details, and our desk assistant will contact you back under 12 hours.
                </p>
              </div>

              <form onSubmit={handleContactSubmit} className="space-y-4">
                {errorText && (
                  <div className="p-3 bg-rose-50 text-rose-700 text-xs font-bold rounded-xl border border-rose-100">
                    {errorText}
                  </div>
                )}

                {/* Patient Name */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Your Name*
                  </label>
                  <input
                    type="text"
                    required
                    id="contact-form-name"
                    placeholder="e.g. Amit Sharma"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white"
                  />
                </div>

                {/* Patient Phone */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    10-Digit Phone Number*
                  </label>
                  <div className="relative">
                    <span className="absolute left-3 top-2.5 text-slate-400 text-sm font-semibold">+91</span>
                    <input
                      type="tel"
                      required
                      maxLength={10}
                      id="contact-form-phone"
                      placeholder="9876543210"
                      value={phone}
                      onChange={(e) => setPhone(e.target.value.replace(/\D/g, ''))}
                      className="w-full pl-12 pr-4 py-2.5 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white"
                    />
                  </div>
                </div>

                {/* Email (Optional) */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Email Address (Optional)
                  </label>
                  <input
                    type="email"
                    id="contact-form-email"
                    placeholder="e.g. amit@gmail.com"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white"
                  />
                </div>

                {/* Message */}
                <div>
                  <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">
                    Your Question / Message*
                  </label>
                  <textarea
                    required
                    id="contact-form-message"
                    placeholder="Write details e.g. looking for cost quotation on titanium implants, veneers, or booking braces..."
                    value={massage}
                    onChange={(e) => setMassage(e.target.value)}
                    rows={4}
                    className="w-full px-4 py-2.5 border border-slate-200 rounded-xl text-slate-800 placeholder-slate-400 bg-slate-50 focus:outline-none focus:ring-2 focus:ring-blue-100 focus:bg-white"
                  />
                </div>

                <button
                  type="submit"
                  id="btn-contact-form-submit"
                  className="w-full py-3.5 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white font-extrabold rounded-xl text-xs shadow-md transition-all active:scale-98"
                >
                  Send Support Ticket
                </button>
              </form>

              {/* Dynamic Popup Overlay Success */}
              <AnimatePresence>
                {isSubmitSuccess && (
                  <motion.div
                    initial={{ opacity: 0 }}
                    animate={{ opacity: 1 }}
                    exit={{ opacity: 0 }}
                    className="absolute inset-0 bg-[#0F4C81]/95 text-white z-20 flex flex-col items-center justify-center text-center p-6"
                  >
                    <div className="p-3 bg-emerald-500 rounded-full text-white mb-4 shadow">
                      <CheckCircle className="w-10 h-10" />
                    </div>
                    <h4 className="text-xl font-bold">Message Lodged!</h4>
                    <p className="text-blue-100 text-xs mt-2 px-4 leading-normal max-w-sm line-clamp-4">
                      Thank you, <span className="font-extrabold text-teal-300">{name}</span>. Your support request has been registered in our database. Dr. Ankush's executive desk will ring you back shortly.
                    </p>
                    <button
                      onClick={handleResetSuccess}
                      className="mt-6 px-5 py-2.5 bg-white text-[#0F4C81] font-extrabold rounded-xl text-[11px] transition-all"
                    >
                      Write Another message
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>

            </div>
          </div>

        </section>

      </div>
    </motion.div>
  );
}
