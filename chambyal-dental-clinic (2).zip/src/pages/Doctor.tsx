import React, { useState } from 'react';
import { doctorsData } from '../data';
import { Award, GraduationCap, CheckCircle2, Clock, Calendar, ShieldCheck, Heart, ArrowRight } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import doctorImg from '../assets/images/regenerated_image_1780212828195.jpg';

interface DoctorProps {
  setCurrentPage: (page: string) => void;
}

export default function Doctor({ setCurrentPage }: DoctorProps) {
  const [activeIdx, setActiveIdx] = useState(0);
  const selectedDoctor = doctorsData[activeIdx] || doctorsData[0];

  // Map the locally loaded high-resolution image to Dr. Ankush to avoid breaking any references, and use robust clinical fallbacks for other specialists
  const getSelectedDoctorImg = (name: string) => {
    if (name.includes('Ankush')) {
      return doctorImg;
    }
    return selectedDoctor.imageUrl;
  };

  const currentImg = getSelectedDoctorImg(selectedDoctor.name);

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#F8FAFC] py-12 md:py-16 min-h-screen"
      id="doctor-profile-root"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Top Header Section */}
        <div className="text-center max-w-3xl mx-auto mb-12">
          <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest block">World-Class Specialists</span>
          <h1 className="text-3xl md:text-4xl font-extrabold text-slate-950 tracking-tight leading-tight mt-1">
            Meet Our Expert Medical Team
          </h1>
          <p className="text-slate-500 text-xs sm:text-sm mt-3 leading-relaxed">
            Our clinical board comprises highly qualified dental surgeons, gold medalist prosthodontists, and certified aligners experts committed to advanced dental therapeutics.
          </p>
        </div>

        {/* Doctor Selection Tabs Grid */}
        <section className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-16" id="doctors-tab-selection-grid">
          {doctorsData.map((doc, idx) => {
            const isActive = idx === activeIdx;
            const docImage = doc.name.includes('Ankush') ? doctorImg : doc.imageUrl;
            
            return (
              <button
                key={doc.name}
                onClick={() => setActiveIdx(idx)}
                className={`text-left p-5 rounded-2xl border transition-all duration-300 relative overflow-hidden flex items-center gap-4 group ${
                  isActive 
                    ? 'bg-white border-[#0F4C81] shadow-xl ring-2 ring-[#0F4C81]/10' 
                    : 'bg-white/60 hover:bg-white border-slate-150 hover:border-slate-300 hover:shadow-md'
                }`}
              >
                {/* Micro avatar */}
                <div className="w-16 h-16 rounded-xl overflow-hidden shrink-0 border-2 border-slate-100 shadow-inner relative">
                  <img 
                    src={docImage} 
                    alt={doc.name} 
                    className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                    referrerPolicy="no-referrer"
                    onError={(e) => {
                      e.currentTarget.src = "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=150";
                    }}
                  />
                  {isActive && (
                    <div className="absolute inset-0 bg-[#0F4C81]/10 flex items-center justify-center">
                      <div className="w-2.5 h-2.5 bg-[#20B2AA] rounded-full ring-4 ring-white animate-pulse"></div>
                    </div>
                  )}
                </div>

                <div className="space-y-0.5">
                  <span className={`text-[10px] font-black uppercase tracking-wider block ${isActive ? 'text-[#20B2AA]' : 'text-slate-400'}`}>
                    {idx === 0 ? 'Clinical Director' : doc.name.includes('Amarjit') ? 'Managing Director' : 'Senior Specialist'}
                  </span>
                  <h3 className="font-extrabold text-slate-900 text-sm md:text-base leading-snug tracking-tight">
                    {doc.name}
                  </h3>
                  <p className="text-slate-500 text-xs font-semibold leading-none mt-1 truncate max-w-[200px]">
                    {doc.degrees[1] || doc.degrees[0]}
                  </p>
                </div>

                {/* Arrow hint indicator */}
                <div className={`ml-auto w-8 h-8 rounded-full flex items-center justify-center shrink-0 transition-all ${
                  isActive ? 'bg-[#0F4C81] text-white' : 'bg-slate-50 text-slate-400 group-hover:bg-slate-100 group-hover:text-slate-700'
                }`}>
                  <ArrowRight className="w-4 h-4" />
                </div>
              </button>
            );
          })}
        </section>

        {/* Dynamic Selected Doctor Portfolio Detail Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={selectedDoctor.name}
            initial={{ opacity: 0, y: 15 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -15 }}
            transition={{ duration: 0.3 }}
            className="grid grid-cols-1 lg:grid-cols-12 gap-12 lg:gap-16 items-start"
            id="active-doctor-portfolio-card"
          >
            
            {/* Left Column: Doctor Photo & Stats Card */}
            <div className="lg:col-span-4 space-y-6 lg:sticky lg:top-24">
              
              <div className="rounded-3xl overflow-hidden border-8 border-white shadow-2xl relative bg-slate-100 group">
                <img
                  src={currentImg}
                  alt={selectedDoctor.name}
                  referrerPolicy="no-referrer"
                  className="w-full h-[460px] object-cover transition-transform duration-700 group-hover:scale-102"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=800";
                  }}
                />
                <div className="absolute top-4 left-4 bg-[#20B2AA] text-white px-3.5 py-1.5 rounded-full text-xs font-bold shadow-md">
                  {selectedDoctor.name.includes('Ankush') ? 'Clinical Director' : selectedDoctor.name.includes('Amarjit') ? 'Managing Director' : 'Consulting Partner'}
                </div>
              </div>

              {/* Practical clinical stats card */}
              <div className="bg-white rounded-3xl p-6 border border-slate-150 shadow-lg space-y-4">
                <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                  <span className="text-xs text-slate-500 font-bold uppercase tracking-wider">Clinical Status</span>
                  <span className="px-2.5 py-1 bg-emerald-50 text-emerald-700 text-[10px] font-extrabold rounded-full uppercase tracking-wider flex items-center gap-1">
                    <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span> Available Today
                  </span>
                </div>

                <div className="space-y-3 font-semibold text-slate-800 text-sm">
                  <div className="flex items-center gap-3">
                    <Clock className="w-4.5 h-4.5 text-[#0F4C81] shrink-0" />
                    <span>{selectedDoctor.experienceYears}+ Years Clinical Practice</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <GraduationCap className="w-4.5 h-4.5 text-[#0F4C81] shrink-0" />
                    <span>{selectedDoctor.degrees[0]}</span>
                  </div>
                  <div className="flex items-center gap-3">
                    <Award className="w-4.5 h-4.5 text-[#0F4C81] shrink-0" />
                    <span>{selectedDoctor.degrees[1] || 'Accredited Board Specialist'}</span>
                  </div>
                </div>

                <button
                  onClick={() => {
                    setCurrentPage('booking');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="w-full mt-4 py-3 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white font-extrabold text-xs tracking-wider uppercase rounded-xl text-center shadow transition-all hover:scale-[1.02]"
                >
                  Book Slot with {selectedDoctor.name.split(' ')[1]}
                </button>
              </div>

            </div>

            {/* Right Column: Full detailed bio and specs */}
            <div className="lg:col-span-8 space-y-8">
              <div>
                <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest block">
                  {selectedDoctor.title}
                </span>
                <h2 className="text-3xl md:text-4xl font-extrabold text-slate-900 tracking-tight leading-tight mt-1">
                  {selectedDoctor.name}
                </h2>
                <p className="text-slate-600 text-xs sm:text-sm font-semibold tracking-wide mt-2">
                  {selectedDoctor.degrees.join(' | ')}
                </p>
              </div>

              {/* Philosophy quote */}
              <div className="p-6 md:p-8 bg-[#0F4C81]/5 rounded-3xl border-l-4 border-[#0F4C81] relative">
                <svg className="absolute top-6 left-6 w-12 h-12 text-[#0F4C81]/10 -z-10 fill-current" viewBox="0 0 24 24">
                  <path d="M14.017 21v-7.391c0-5.704 3.731-9.57 8.983-10.609l.995 2.151c-2.432.917-3.995 3.638-3.995 5.849h4v10h-9.983zm-14.017 0v-7.391c0-5.704 3.748-9.57 9-10.609l.996 2.151c-2.433.917-3.996 3.638-3.996 5.849h3.983v10h-9.983z" />
                </svg>
                <p className="text-slate-800 text-sm md:text-base italic leading-relaxed font-semibold">
                  {selectedDoctor.treatmentPhilosophy}
                </p>
                <div className="flex items-center gap-2 mt-4 text-[#0F4C81] text-xs font-bold uppercase tracking-wider">
                  <Heart className="w-4 h-4 fill-current text-rose-500 animate-pulse" />
                  <span>{selectedDoctor.name}</span>
                </div>
              </div>

              {/* Full Biography Sections */}
              <div className="space-y-4 text-slate-700 text-xs sm:text-sm leading-relaxed font-normal">
                <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">Professional Biography</h3>
                {selectedDoctor.biography.map((paragraph, index) => (
                  <p key={index}>{paragraph}</p>
                ))}
              </div>

              {/* Core Specialization tags */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">Primary Specializations</h3>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {selectedDoctor.specializations.map((spec, index) => (
                    <div key={index} className="flex items-start gap-2.5 bg-white p-4 rounded-xl border border-slate-150">
                      <CheckCircle2 className="w-5 h-5 text-[#20B2AA] shrink-0 mt-0.5" />
                      <span className="text-slate-800 text-xs sm:text-sm font-semibold leading-relaxed">{spec}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Certifications and credentials list */}
              <div className="space-y-4">
                <h3 className="text-lg font-bold text-slate-900 border-b border-slate-100 pb-2">Honors, Awards, and Affiliations</h3>
                <ul className="space-y-4">
                  {selectedDoctor.achievements.map((ach, index) => (
                    <li key={index} className="flex gap-4 p-4.5 bg-slate-50 border border-slate-200 rounded-2xl">
                      <div className="w-10 h-10 rounded-full bg-[#0F4C81]/10 text-[#0F4C81] flex items-center justify-center shrink-0">
                        <Award className="w-5 h-5" />
                      </div>
                      <div>
                        <h4 className="font-bold text-[#0F4C81] text-xs sm:text-sm">{ach}</h4>
                        <p className="text-[11px] text-slate-500 mt-1 font-semibold">Active authorized dental board contribution.</p>
                      </div>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Clinical safety quality assurance stamp */}
              <div className="p-6 bg-slate-900 text-white rounded-3xl border border-slate-850 flex flex-col sm:flex-row items-center gap-6 justify-between">
                <div className="space-y-1">
                  <p className="text-sm font-bold flex items-center gap-1.5 text-teal-400">
                    <ShieldCheck className="w-4.5 h-4.5 text-[#20B2AA] shrink-0" />
                    <span>Licensed State Health Practitioner</span>
                  </p>
                  <p className="text-slate-400 text-xs font-semibold leading-relaxed">
                    Registered under Dental Council guidelines with rigid clinical sterilization protocols.
                  </p>
                </div>
                <button
                  onClick={() => {
                    setCurrentPage('booking');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-5 py-2.5 bg-white text-slate-950 hover:bg-slate-50 font-bold rounded-lg text-xs"
                >
                  Inquire Slot Directly
                </button>
              </div>

            </div>

          </motion.div>
        </AnimatePresence>

      </div>
    </motion.div>
  );
}
