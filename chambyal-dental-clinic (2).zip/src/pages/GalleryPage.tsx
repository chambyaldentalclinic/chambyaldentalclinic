import { useState } from 'react';
import { galleryData } from '../data';
import { 
  X, 
  Expand, 
  ChevronLeft, 
  ChevronRight, 
  Sparkles, 
  Image as ImageIcon 
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

export default function GalleryPage() {
  const [selectedFilter, setSelectedFilter] = useState<string>('all');
  const [activePhotoIndex, setActivePhotoIndex] = useState<number | null>(null);

  const filterTabs = [
    { id: 'all', label: 'Complete Gallery' },
    { id: 'interior', label: 'Clinic Lounge' },
    { id: 'equipment', label: 'Advanced Machinery' },
    { id: 'treatment', label: 'Treatment operatories' },
    { id: 'transformation', label: 'Smile Transformations' }
  ];

  // Active filter computation
  const filteredPhotos = galleryData.filter((photo) => {
    if (selectedFilter === 'all') return true;
    return photo.category === selectedFilter;
  });

  const openLightbox = (photoId: string) => {
    // Find absolute index inside original galleryData to allow logical navigation
    const origIndex = galleryData.findIndex((item) => item.id === photoId);
    if (origIndex !== -1) {
      setActivePhotoIndex(origIndex);
    }
  };

  const closeLightbox = () => {
    setActivePhotoIndex(null);
  };

  const navigateLightbox = (direction: 'prev' | 'next') => {
    if (activePhotoIndex === null) return;
    
    let newIndex = activePhotoIndex;
    if (direction === 'prev') {
      newIndex = activePhotoIndex - 1 < 0 ? galleryData.length - 1 : activePhotoIndex - 1;
    } else {
      newIndex = activePhotoIndex + 1 >= galleryData.length ? 0 : activePhotoIndex + 1;
    }
    setActivePhotoIndex(newIndex);
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#F8FAFC] py-16 min-h-screen"
      id="gallery-showcase-page"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Title sections */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-[#0F4C81] text-xs font-bold uppercase tracking-widest block flex items-center justify-center gap-1.5">
            <Sparkles className="w-4.5 h-4.5 text-[#20B2AA]" /> Exploring Diagnostic Excellence
          </span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Chambyal Clinical Gallery
          </h1>
          <p className="text-slate-600 text-sm leading-relaxed">
            Take a virtual tour of our sterilized private dental operatories, cutting-edge surgical gear, and aesthetic smile designs.
          </p>
        </div>

        {/* Filter Selection Ribbon tabs */}
        <div className="flex flex-wrap justify-center gap-3 mb-12" id="gallery-category-chips-ribbon">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedFilter(tab.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wide transition-all border ${
                selectedFilter === tab.id
                  ? 'bg-[#0F4C81] text-white border-[#0F4C81] shadow-md'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-350 hover:bg-slate-50'
              }`}
              id={`gallery-filter-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Masonry-like grid container */}
        <div className="columns-1 sm:columns-2 lg:columns-3 gap-6 space-y-6" id="gallery-masonry-container">
          {filteredPhotos.map((item) => (
            <div
              key={item.id}
              onClick={() => openLightbox(item.id)}
              className="break-inside-avoid bg-white rounded-2xl overflow-hidden border border-slate-150 shadow-md hover:shadow-xl transition-all duration-300 cursor-pointer group relative"
              id={`gallery-thumbnail-${item.id}`}
            >
              {/* Photo */}
              <div className="relative overflow-hidden">
                <img
                  src={item.imageUrl}
                  alt={item.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-auto object-cover group-hover:scale-[1.03] transition-transform duration-500"
                />
                
                {/* Visual hover layout panel */}
                <div className="absolute inset-0 bg-[#0F4C81]/40 opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex items-center justify-center">
                  <div className="w-10 h-10 rounded-full bg-white shadow-lg flex items-center justify-center text-[#0F4C81]">
                    <Expand className="w-5 h-5" />
                  </div>
                </div>
              </div>

              {/* Descriptions bottom card */}
              <div className="p-5 space-y-1 bg-white">
                <span className="text-[10px] font-extrabold text-[#20B2AA] uppercase tracking-widest block leading-none">
                  {item.category}
                </span>
                <h3 className="font-bold text-slate-900 text-xs sm:text-sm tracking-tight leading-snug">
                  {item.title}
                </h3>
                {item.description && (
                  <p className="text-[11px] text-slate-500 leading-normal line-clamp-2 pt-1 font-semibold">
                    {item.description}
                  </p>
                )}
              </div>

            </div>
          ))}
        </div>

        {/* No images diagnostic support link falls */}
        {filteredPhotos.length === 0 && (
          <div className="text-center py-16 space-y-3 bg-white border border-dashed rounded-3xl p-8 border-slate-200">
            <ImageIcon className="w-12 h-12 text-slate-400 mx-auto" />
            <p className="font-bold text-slate-600 text-sm">No images listed in this specific tab yet.</p>
            <p className="text-slate-400 text-xs">We keep uploading real surgical cases periodically.</p>
          </div>
        )}

      </div>

      {/* Lightbox Animated Display Modal */}
      <AnimatePresence>
        {activePhotoIndex !== null && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            className="fixed inset-0 bg-slate-950/95 z-55 flex flex-col items-center justify-center p-4"
            id="gallery-lightbox-modal"
          >
            {/* Top Bar actions */}
            <div className="absolute top-4 right-4 sm:top-6 sm:right-6 flex items-center gap-3">
              <span className="text-xs text-slate-400 font-bold font-mono">
                {activePhotoIndex + 1} / {galleryData.length}
              </span>
              <button
                onClick={closeLightbox}
                className="p-2 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors"
                title="Close overlay"
              >
                <X className="w-6 h-6" />
              </button>
            </div>

            {/* Main Interactive Slide Arena */}
            <div className="flex items-center justify-between gap-6 w-full max-w-5xl relative">
              
              {/* Prev control */}
              <button
                onClick={() => navigateLightbox('prev')}
                className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors shrink-0 hidden sm:block"
                title="Previous design"
              >
                <ChevronLeft className="w-6 h-6" />
              </button>

              {/* Central Active image with descriptions */}
              <div className="flex-1 flex flex-col items-center justify-center space-y-6 my-auto">
                <motion.img
                  key={activePhotoIndex}
                  initial={{ opacity: 0, scale: 0.95 }}
                  animate={{ opacity: 1, scale: 1 }}
                  exit={{ opacity: 0, scale: 0.95 }}
                  transition={{ duration: 0.25 }}
                  src={galleryData[activePhotoIndex].imageUrl}
                  alt={galleryData[activePhotoIndex].title}
                  referrerPolicy="no-referrer"
                  className="max-h-[60vh] sm:max-h-[70vh] max-w-full object-contain rounded-2xl shadow-2xl border-4 border-slate-900"
                />

                <div className="text-center space-y-1.5 max-w-lg">
                  <span className="text-xs font-extrabold text-[#20B2AA] uppercase tracking-widest block">
                    {galleryData[activePhotoIndex].category}
                  </span>
                  <h3 className="text-white text-lg font-bold tracking-tight">
                    {galleryData[activePhotoIndex].title}
                  </h3>
                  {galleryData[activePhotoIndex].description && (
                    <p className="text-xs text-slate-400 leading-normal font-semibold">
                      {galleryData[activePhotoIndex].description}
                    </p>
                  )}
                </div>
              </div>

              {/* Next control */}
              <button
                onClick={() => navigateLightbox('next')}
                className="p-3 rounded-full bg-white/10 hover:bg-white/20 text-white transition-colors shrink-0 hidden sm:block"
                title="Next design"
              >
                <ChevronRight className="w-6 h-6" />
              </button>

            </div>

            {/* Mobile indicator slide buttons below photo */}
            <div className="flex sm:hidden items-center justify-center gap-8 py-4 w-full mt-2">
              <button
                onClick={() => navigateLightbox('prev')}
                className="p-2 rounded-full bg-white/10 text-white"
              >
                <ChevronLeft className="w-5 h-5" />
              </button>
              <button
                onClick={() => navigateLightbox('next')}
                className="p-2 rounded-full bg-white/10 text-white"
              >
                <ChevronRight className="w-5 h-5" />
              </button>
            </div>

          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
}
