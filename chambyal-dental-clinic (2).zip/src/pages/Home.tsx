import React, { useState } from 'react';
import { servicesData, reviewsData, faqsData, doctorProfile, galleryData, doctorsData } from '../data';
import { 
  Calendar, 
  Phone, 
  CheckCircle, 
  Star, 
  Plus, 
  Minus, 
  ArrowRight, 
  Clock, 
  Award, 
  Users, 
  Clock3, 
  ShieldCheck, 
  MapPin, 
  Sparkles,
  Heart,
  ChevronRight,
  ExternalLink
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// New imported images
import heroImg from '../assets/images/regenerated_image_1780217919564.jpg';
import aboutImg from '../assets/images/regenerated_image_1780217921431.jpg';
import doctorImg from '../assets/images/regenerated_image_1780212828195.jpg';

interface HomeProps {
  setCurrentPage: (page: string) => void;
  setSelectedTreatment?: (treatment: string) => void;
}

export default function Home({ setCurrentPage, setSelectedTreatment }: HomeProps) {
  const [activeFaq, setActiveFaq] = useState<string | null>('faq-1');

  // Interactive slider state for Before & After preview
  const [sliderPosition, setSliderPosition] = useState(50);
  const [isResizing, setIsResizing] = useState(false);

  const stats = [
    { label: 'Experienced Years', value: '30+', icon: Clock3 },
    { label: 'Happy Patients', value: '15,000+', icon: Users },
    { label: 'Dental Implants Done', value: '2,500+', icon: Award },
    { label: 'Sterilization Guarantee', value: '100%', icon: ShieldCheck },
  ];

  const handleBookNow = (treatmentId: string = '') => {
    if (setSelectedTreatment) {
      setSelectedTreatment(treatmentId);
    }
    setCurrentPage('booking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleLearnMoreService = () => {
    setCurrentPage('services');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleMobileHover = (e: React.MouseEvent<HTMLDivElement> | React.TouchEvent<HTMLDivElement>) => {
    const container = e.currentTarget;
    const rect = container.getBoundingClientRect();
    const clientX = 'touches' in e ? e.touches[0].clientX : e.clientX;
    const x = clientX - rect.left;
    const percentage = Math.max(0, Math.min(100, (x / rect.width) * 100));
    setSliderPosition(percentage);
  };

  const clinicPhone = '+919459778337';
  const whatsappUrl = `https://wa.me/919459778337?text=${encodeURIComponent(
    'Hello Chambyal Dental Clinic. I am looking for a dental checkup and would like to learn more about your services.'
  )}`;

  return (
    <motion.div
      initial={{ opacity: 0, y: 15 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0 }}
      transition={{ duration: 0.4 }}
      className="bg-[#F8FAFC]"
      id="home-page-container"
    >
      {/* ----------------- 1. HERO SECTION ----------------- */}
      <section className="relative overflow-hidden bg-gradient-to-b from-[#0F4C81]/10 via-[#F8FAFC] to-[#F8FAFC] pt-12 pb-24 md:py-32">
        <div className="absolute top-0 right-0 w-96 h-96 bg-blue-300/10 rounded-full blur-3xl"></div>
        <div className="absolute bottom-10 left-10 w-80 h-80 bg-teal-300/10 rounded-full blur-3xl"></div>

        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 relative">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Left Texts & CTAs */}
            <div className="lg:col-span-7 space-y-6 text-center lg:text-left">
              <div className="inline-flex items-center gap-2.5 px-5 py-2 bg-[#0F4C81]/15 rounded-full border-2 border-[#0F4C81] shadow-[0_0_18px_rgba(15,76,129,0.4)] transition-all duration-350 hover:shadow-[0_0_25px_rgba(15,76,129,0.6)]">
                <Sparkles className="w-5 h-5 text-[#0F4C81] animate-pulse" />
                <span className="text-sm font-black text-[#0F4C81] uppercase tracking-widest drop-shadow-[0_0_6px_rgba(15,76,129,0.5)]">Since 1997</span>
              </div>

              <h1 className="text-4xl sm:text-5xl md:text-6xl font-extrabold text-slate-900 tracking-tight leading-[1.1]">
                Healthy Smiles Begin at <span className="text-[#0F4C81] relative">Chambyal <span className="absolute bottom-1 left-0 w-full h-1.5 bg-teal-400 rounded-full -z-10 bg-opacity-70"></span></span> Dental Clinic
              </h1>

              <p className="text-lg text-slate-600 font-medium leading-relaxed max-w-2xl mx-auto lg:mx-0">
                Advanced, painless, and affordable dental care using modern technology and personalized treatment plans in Barsar, Hamirpur.
              </p>

              {/* Action Buttons Group */}
              <div className="flex flex-col sm:flex-row items-center gap-4 justify-center lg:justify-start pt-3">
                <button
                  onClick={() => handleBookNow('')}
                  id="hero-book-appointment"
                  className="w-full sm:w-auto px-8 py-4 text-sm font-bold bg-[#0F4C81] hover:bg-[#0c3e6b] text-white rounded-full shadow-lg shadow-blue-900/20 hover:scale-105 hover:shadow-xl transition-all flex items-center justify-center gap-2"
                >
                  <Calendar className="w-4.5 h-4.5" />
                  <span>Book Appointment</span>
                </button>

                <a
                  href={`tel:${clinicPhone}`}
                  id="hero-call-now"
                  className="w-full sm:w-auto px-8 py-4 text-sm font-bold bg-white text-slate-800 border border-slate-200 rounded-full hover:bg-slate-50 shadow-sm hover:scale-105 transition-all text-center flex items-center justify-center gap-2"
                >
                  <Phone className="w-4.5 h-4.5 text-[#20B2AA]" />
                  <span>Call Now</span>
                </a>

                <a
                  href={whatsappUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  id="hero-whatsapp-consultation"
                  className="w-full sm:w-auto px-8 py-4 text-sm font-bold bg-[#25D366] hover:bg-emerald-600 text-white rounded-full hover:scale-105 transition-all text-center flex items-center justify-center gap-2 shadow-sm"
                >
                  {/* WhatsApp SVG path snippet */}
                  <svg className="w-4.5 h-4.5 fill-current" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                    <path d="M.057 24l1.687-6.163c-1.041-1.804-1.588-3.849-1.587-5.946C.06 5.348 5.397.01 12.008.01c3.202.001 6.212 1.246 8.477 3.514 2.266 2.268 3.507 5.28 3.505 8.484-.004 6.657-5.34 11.997-11.953 11.997-2.005-.001-3.973-.502-5.717-1.456L0 24zm6.59-4.846c1.6.95 3.188 1.449 4.825 1.451 5.436 0 9.86-4.37 9.864-9.799.002-2.63-1.023-5.101-2.885-6.968C16.632 1.97 14.161.947 11.537.947c-5.443 0-9.87 4.372-9.874 9.802-.001 1.737.478 3.43 1.385 4.921L1.937 21.08l5.71-1.926z" />
                  </svg>
                  <span>WhatsApp Consult</span>
                </a>
              </div>

              {/* Verified Trust Badges */}
              <div className="flex flex-wrap items-center justify-center lg:justify-start gap-x-6 gap-y-3 pt-6 border-t border-slate-200">
                <div className="flex items-center gap-1.5 text-slate-600 text-xs font-semibold">
                  <CheckCircle className="w-4.5 h-4.5 text-[#20B2AA]" />
                  <span>NABH Accredited Clinic</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-600 text-xs font-semibold">
                  <CheckCircle className="w-4.5 h-4.5 text-[#20B2AA]" />
                  <span>Class-B Autoclave Sterilization</span>
                </div>
                <div className="flex items-center gap-1.5 text-slate-600 text-xs font-semibold">
                  <CheckCircle className="w-4.5 h-4.5 text-[#20B2AA]" />
                  <span>Painless Treatment Kits</span>
                </div>
              </div>

            </div>

            {/* Right Side Visual Immersive Hero Image */}
            <div className="lg:col-span-5 relative" id="hero-image-visual">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[110%] bg-[#0F4C81]/5 rounded-3xl rotate-3 -z-10"></div>
              
              <div className="relative rounded-3xl overflow-hidden shadow-2xl border-4 border-white">
                <img
                  src={heroImg}
                  alt="Modern Dental Operatory Room Chambyal Dental Clinic"
                  referrerPolicy="no-referrer"
                  className="w-full h-[450px] object-cover hover:scale-105 transition-transform duration-700"
                />

                {/* Overlap patient card */}
                <div className="absolute bottom-6 left-6 right-6 bg-white/95 backdrop-blur-sm p-4 rounded-2xl border border-slate-150 shadow-xl flex items-center gap-3">
                  <div className="w-10 h-10 rounded-full bg-emerald-100 flex items-center justify-center text-emerald-600 shrink-0">
                    <Star className="w-5 h-5 fill-current" />
                  </div>
                  <div>
                    <p className="text-xs text-slate-500 font-semibold tracking-wide">Highly Rated Dental Surgeon</p>
                    <p className="text-sm font-extrabold text-slate-900 mt-0.5">5.0 Star Rated on Google Local Business</p>
                  </div>
                </div>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* ----------------- 1.5 CLINIC METRIC STATS ----------------- */}
      <section className="-mt-8 relative z-25 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 bg-white p-6 sm:p-8 rounded-3xl shadow-xl border border-slate-100">
          {stats.map((stat, idx) => {
            const IconComp = stat.icon;
            return (
              <div key={idx} className="text-center p-3 relative group">
                <div className="mx-auto w-10 h-10 bg-blue-50/70 rounded-xl flex items-center justify-center mb-3 text-[#0F4C81] group-hover:bg-[#0F4C81] group-hover:text-white transition-all">
                  <IconComp className="w-5 h-5" />
                </div>
                <p className="text-3xl font-extrabold text-[#0F4C81] tracking-tight">{stat.value}</p>
                <p className="text-xs font-bold text-slate-500 mt-1 uppercase tracking-wider">{stat.label}</p>
                {idx < 3 && (
                  <div className="hidden lg:block absolute right-0 top-1/2 -translate-y-1/2 w-px h-12 bg-slate-100"></div>
                )}
              </div>
            );
          })}
        </div>
      </section>


      {/* ----------------- 2. ABOUT CLINIC QUICK PREVIEW ----------------- */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          
          <div className="lg:col-span-5 relative order-last lg:order-first">
            <img
              src={aboutImg}
              alt="Friendly patient check-up at Chambyal Dental Clinic"
              referrerPolicy="no-referrer"
              className="rounded-3xl shadow-xl object-cover w-full h-[400px]"
            />
            <div className="absolute -bottom-6 -right-6 p-6 bg-[#20B2AA] text-white rounded-2xl shadow-xl max-w-xs">
              <p className="font-extrabold text-base leading-tight">Patient-First Philosophy</p>
              <p className="text-xs text-teal-50 mt-2 leading-relaxed">
                "We customize every treatment protocol. Our painless dental devices make visits pleasant for adults and children alike."
              </p>
            </div>
          </div>

          <div className="lg:col-span-7 space-y-6">
            <span className="text-[#20B2AA] font-bold text-xs tracking-widest uppercase">About Our Dental Care Center</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              A Private Clinic Designed for Excellence, Safety, and Compassion
            </h2>
            <p className="text-slate-600 text-sm leading-relaxed font-semibold">
              Chambyal Dental Clinic was founded by Amarjit Singh, M.D to deliver the highest international dentist clinical benchmarks to Hamirpur district. Our clinic is styled on sleek, hygienic parameters to minimize infection risks, and maximize patient comfort.
            </p>
            <p className="text-slate-500 text-sm leading-relaxed">
              We understand that many patients suffer from "dental anxiety". That is why we emphasize high comfort anesthesia, single-visit tooth solutions, digital CAD scanners to eliminate messy impression clays, and active transparent consultation.
            </p>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 pb-4">
              {[
                'Sterilized in Class B autoclaves (EU standardized)',
                'Metal-free bio-compatible dental crowns',
                'Painless local micro-anesthesia system',
                'Transparent billing with no hidden costs',
              ].map((point, i) => (
                <div key={i} className="flex items-center gap-3">
                  <div className="w-6 h-6 rounded-full bg-emerald-100 flex items-center justify-center shrink-0">
                    <CheckCircle className="w-3.5 h-3.5 text-emerald-600" />
                  </div>
                  <span className="text-slate-700 text-sm font-semibold">{point}</span>
                </div>
              ))}
            </div>

            <button
              onClick={() => {
                setCurrentPage('about');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="flex items-center gap-2 group text-[#0F4C81] font-bold text-sm tracking-wide"
            >
              Learn More About Our Clean Protocols
              <ArrowRight className="w-4 h-4 transition-transform group-hover:translate-x-1.5" />
            </button>
          </div>

        </div>
      </section>


      {/* ----------------- 3. WHY CHOOSE US SECTION ----------------- */}
      <section className="py-20 bg-[#0F4C81] text-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
            <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest">Why Choose Chambyal Dental Clinic</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-white tracking-tight">
              Clinically Outstanding Features That Drive Your Safety
            </h2>
            <p className="text-blue-100 text-sm leading-relaxed">
              With over 30 years of clinical dedication in the Hamirpur-Barsar region, our dentistry centers around advanced parameters, transparency, and top-tier materials.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {[
              {
                title: 'NABH Accredited Clinic',
                details: 'Fully certified for maintaining superior patient safety benchmarks, high-standard dental infrastructure, and healthcare protocols.',
                bg: 'bg-white/5 border-white/10'
              },
              {
                title: 'Advanced Diagnostic Scanning',
                details: 'Utilizing modern digital scanners, high precision apex locators, and rotary endodontics for pain-free treatment.',
                bg: 'bg-white/5 border-white/10'
              },
              {
                title: 'Zero Infection Isolation Protocols',
                details: 'We autoclave every explorer, mirror, surgical bur, and clean water pipelines on a daily parameters checklist.',
                bg: 'bg-white/5 border-white/10'
              },
              {
                title: 'FDA Certified Materials Only',
                details: 'Zirconia crown warranties of up to 15 years, biocompatible titanium implants, and premium tooth fillings.',
                bg: 'bg-white/5 border-white/10'
              }
            ].map((card, i) => (
              <div key={i} className={`p-6 rounded-3xl border ${card.bg} space-y-4 transition-transform hover:-translate-y-1.5`}>
                <div className="w-10 h-10 rounded-2xl bg-[#20B2AA] flex items-center justify-center text-white font-extrabold text-sm">
                  {i + 1}
                </div>
                <h3 className="text-lg font-bold text-white tracking-tight">{card.title}</h3>
                <p className="text-blue-100/85 text-xs h-[100px] sm:h-auto overflow-hidden leading-relaxed">{card.details}</p>
              </div>
            ))}
          </div>
        </div>
      </section>


      {/* ----------------- 4. FEATURED DENTAL SERVICES ----------------- */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-6 mb-16">
          <div className="max-w-2xl space-y-3">
            <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest">Our Featured Treatment Domains</span>
            <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
              Empowering Healthy Smiles Through Skilled Clinical Dentistry
            </h2>
            <p className="text-slate-600 text-sm">
              Explore our core treatments designed to restore perfect jaw functions and visual aesthetics.
            </p>
          </div>
          <button
            onClick={handleLearnMoreService}
            className="px-6 py-3 bg-white text-[#0F4C81] border border-slate-200 hover:bg-slate-50 font-bold rounded-full text-xs shadow-sm flex items-center gap-2 group transition-all shrink-0 hover:scale-105"
          >
            <span>View All 12 Services</span>
            <ArrowRight className="w-3.5 h-3.5 transition-transform group-hover:translate-x-1" />
          </button>
        </div>

        {/* 3 Prominent Featured Service Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {servicesData.slice(0, 3).map((ser) => (
            <div key={ser.id} className="bg-white rounded-3xl border border-slate-100 shadow-lg overflow-hidden flex flex-col group hover:-translate-y-1 duration-300">
              <div className="h-56 relative overflow-hidden">
                <img
                  src={ser.imageUrl}
                  alt={ser.title}
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                />
                <div className="absolute top-4 left-4 px-3 py-1 bg-[#0F4C81] text-white rounded-full text-[10px] font-extrabold uppercase tracking-widest">
                  Featured Service
                </div>
              </div>
              
              <div className="p-6 md:p-8 flex-1 flex flex-col justify-between">
                <div className="space-y-3">
                  <h3 className="text-xl font-bold text-slate-950 tracking-tight group-hover:text-[#0F4C81] transition-colors">{ser.title}</h3>
                  <p className="text-slate-600 text-xs leading-relaxed line-clamp-3">{ser.shortDescription}</p>
                  
                  <div className="pt-2">
                    <p className="text-[11px] font-bold text-slate-800 uppercase tracking-wider">Primary Benefits:</p>
                    <ul className="mt-1 space-y-1.5">
                      {ser.benefits.slice(0, 2).map((ben, i) => (
                        <li key={i} className="flex items-center gap-2 text-xs text-slate-500">
                          <span className="w-1.5 h-1.5 rounded-full bg-[#20B2AA]" />
                          <span className="line-clamp-1 font-semibold">{ben}</span>
                        </li>
                      ))}
                    </ul>
                  </div>
                </div>

                <div className="flex gap-3 pt-6 border-t border-slate-50 mt-6">
                  <button
                    onClick={handleLearnMoreService}
                    className="flex-1 py-2.5 bg-slate-50 hover:bg-slate-150 text-slate-700 font-bold text-xs rounded-lg text-center"
                  >
                    Learn Details
                  </button>
                  <button
                    onClick={() => handleBookNow(ser.id)}
                    className="flex-1 py-2.5 bg-[#0F4C81] text-white hover:bg-[#0c3e6b] font-bold text-xs rounded-lg text-center"
                  >
                    Book Consultation
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>


      {/* ----------------- 5. MEET DR. ANKUSH PREVIEW ----------------- */}
      <section className="py-24 bg-slate-100/70 border-y border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Dr. Photo */}
            <div className="lg:col-span-4 relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[110%] bg-[#0F4C81]/5 rounded-3xl -rotate-2 -z-10"></div>
              <div className="rounded-3xl overflow-hidden border-8 border-white shadow-2xl">
                <img
                  src={doctorImg}
                  alt="Dr. Ankush Chambyal senior implantologist"
                  referrerPolicy="no-referrer"
                  className="w-full h-[450px] object-cover"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1537368910025-700350fe46c7?auto=format&fit=crop&q=80&w=800";
                  }}
                />
              </div>
            </div>

            {/* Dr. Details */}
            <div className="lg:col-span-8 space-y-6">
              <span className="text-[#0F4C81] font-bold text-xs uppercase tracking-widest">Our Chief Dental Surgeon</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                {doctorProfile.name}
              </h2>
              <p className="text-slate-600 font-bold text-sm tracking-wide">
                {doctorProfile.degrees.slice(0, 2).join(' & ')} • Specialist Periodontist & Chief Implantology Expert
              </p>
              
              <div className="p-6 bg-[#0F4C81]/5 rounded-2xl border-l-4 border-[#0F4C81] text-slate-800 text-sm font-medium leading-relaxed space-y-4">
                <p>
                  I am Dr. Ankush Chambyal, MDS in Periodontology and Oral Implantology, dedicated to providing comprehensive dental care with a focus on precision, comfort, and long-term oral health. With over 11 years of clinical experience, I have had the privilege of helping thousands of patients achieve healthier smiles and improved confidence through advanced dental treatments.
                </p>
                <p>
                  My expertise encompasses dental implants, periodontal (gum) therapy, cosmetic dentistry, smile rehabilitation, preventive dental care, and advanced surgical procedures. I believe that every patient deserves individualized treatment, and I strive to create a comfortable and welcoming environment where patients feel informed, valued, and confident about their dental care decisions.
                </p>
                <p>
                  At Chambyal Dental Clinic, we combine modern technology, evidence-based treatment protocols, and the highest standards of sterilization to deliver safe, effective, and painless dental solutions. My commitment to continuous learning and professional excellence ensures that patients receive the latest and most advanced treatment options available in modern dentistry.
                </p>
                <p>
                  Whether you require routine dental care, a complete smile makeover, or advanced implant therapy, my goal is to provide exceptional treatment outcomes while building lasting relationships based on trust, integrity, and patient satisfaction.
                </p>
                <p className="font-bold border-t border-slate-200 pt-3 text-[#0F4C81] italic">
                  “Your smile is our priority, and your oral health is our passion.”
                </p>
              </div>

              <div className="space-y-4 pt-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-widest">Clinical Specialities:</h4>
                <div className="flex flex-wrap gap-2">
                  {doctorProfile.specializations.map((spec, i) => (
                    <span key={i} className="px-3.5 py-1.5 bg-white border border-slate-200 text-slate-700 text-xs font-bold rounded-full">
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => {
                    setCurrentPage('doctor');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-6 py-3.5 bg-[#0F4C81] text-white hover:bg-[#0c3e6b] font-bold rounded-full text-xs shadow-md"
                >
                  View Dr. Biography & Qualifications
                </button>
                <a
                  href="tel:+919459778337"
                  className="px-6 py-3.5 bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 font-semibold rounded-full text-xs text-center"
                >
                  Consult Directly: +91 94597 78337
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* ----------------- 5b. MEET DR. RITIKA PREVIEW ----------------- */}
      <section className="py-24 bg-white border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Dr. Details (Left Column) */}
            <div className="lg:col-span-8 space-y-6 order-last lg:order-first">
              <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest">RCT Expert & Micro Dentistry Specialist</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                {doctorsData[1]?.name || 'Dr. Ritika Chambyal'}
              </h2>
              <p className="text-slate-600 font-bold text-sm tracking-wide">
                BDS (Bachelor of Dental Surgery) •Fellowship in Implantology by IAECD, RCT Expert & Modern Micro-Dentistry Specialist
              </p>
              
              <div className="p-6 bg-teal-50/40 rounded-2xl border-l-4 border-[#20B2AA] text-slate-800 text-sm font-medium leading-relaxed space-y-4">
                <p>
                  Dr. Ritika, BDS is a highly skilled and compassionate dental professional with over 7 years of clinical experience in providing comprehensive dental care. She is particularly known for her expertise in Root Canal Treatment (RCT) and is committed to preserving natural teeth through precise, painless, and effective endodontic procedures.
                </p>
                <p>
                  With a patient-centered approach, Dr. Ritika believes in delivering treatment with the utmost care, comfort, and attention to detail. Her clinical expertise extends across restorative dentistry, preventive dental care, cosmetic procedures, and management of dental pain and infections. She is dedicated to helping patients achieve optimal oral health while ensuring a stress-free and comfortable dental experience.
                </p>
                <p>
                  At Chambyal Dental Clinic, Dr. Ritika utilizes modern techniques and advanced equipment to provide high-quality dental treatments tailored to the individual needs of each patient. Her gentle chairside manner, commitment to excellence, and focus on patient education have earned the trust and appreciation of numerous patients over the years.
                </p>
                <p>
                  Whether it is a routine dental check-up, a complex root canal procedure, or restorative treatment, Dr. Ritika strives to deliver exceptional results while maintaining the highest standards of professionalism and patient care.
                </p>
                <p className="font-bold border-t border-teal-200/40 pt-3 text-[#20B2AA] italic">
                  {doctorsData[1]?.treatmentPhilosophy}
                </p>
              </div>

              <div className="space-y-4 pt-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-widest">Clinical Specialities:</h4>
                <div className="flex flex-wrap gap-2">
                  {doctorsData[1]?.specializations.map((spec, i) => (
                    <span key={i} className="px-3.5 py-1.5 bg-slate-50 border border-slate-200 text-slate-700 text-xs font-bold rounded-full">
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => {
                    setCurrentPage('doctor');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-6 py-3.5 bg-[#20B2AA] hover:bg-[#1a938c] text-white font-bold rounded-full text-xs shadow-md"
                >
                  View Dr. Biography & Qualifications
                </button>
                <a
                  href="tel:+919882346377"
                  className="px-6 py-3.5 bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 font-semibold rounded-full text-xs text-center"
                >
                  Consult Directly: +91 98823 46377
                </a>
              </div>
            </div>

            {/* Dr. Photo (Right Column) */}
            <div className="lg:col-span-4 relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[110%] bg-[#20B2AA]/5 rounded-3xl rotate-2 -z-10"></div>
              <div className="rounded-3xl overflow-hidden border-8 border-white shadow-2xl">
                <img
                  src={doctorsData[1]?.imageUrl || 'https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=600'}
                  alt="Dr. Ritika Chambyal RCT Expert"
                  referrerPolicy="no-referrer"
                  className="w-full h-[450px] object-cover hover:scale-103 transition-transform duration-500"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1559839734-2b71ea197ec2?auto=format&fit=crop&q=80&w=600";
                  }}
                />
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* ----------------- 5c. MEET MANAGING DIRECTOR MR. AMARJIT SINGH PREVIEW ----------------- */}
      <section className="py-24 bg-slate-50 border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Dr. Photo (Left Column) */}
            <div className="lg:col-span-4 relative">
              <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[110%] h-[110%] bg-[#0F4C81]/5 rounded-3xl -rotate-3 -z-10"></div>
              <div className="rounded-3xl overflow-hidden border-8 border-white shadow-2xl">
                <img
                  src={doctorsData[2]?.imageUrl || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=600'}
                  alt="Mr. Amarjit Singh Managing Director"
                  referrerPolicy="no-referrer"
                  className="w-full h-[450px] object-cover hover:scale-103 transition-transform duration-500"
                  onError={(e) => {
                    e.currentTarget.src = "https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&q=80&w=600";
                  }}
                />
              </div>
            </div>

            {/* Dr. Details (Right Column) */}
            <div className="lg:col-span-8 space-y-6">
              <span className="text-[#0F4C81] font-bold text-xs uppercase tracking-widest">Managing Director</span>
              <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
                {doctorsData[2]?.name || 'Mr. Amarjit Singh'}
              </h2>
              <p className="text-slate-600 font-bold text-sm tracking-wide">
                {doctorsData[2]?.degrees.join(' • ') || 'Dental Hygienist (DH) Course - AFMC, Pune'}
              </p>
              
              <div className="p-6 bg-blue-50/50 rounded-2xl border-l-4 border-[#0F4C81] text-slate-800 text-sm font-medium leading-relaxed space-y-4">
                <p>
                  Mr. Amarjit Singh is the Managing Director of Chambyal Dental Clinic and a respected healthcare professional with more than 40 years of experience in the field of dental healthcare and patient services. He completed his Dental Hygienist (DH) Course from Armed Forces Medical College (AFMC), Pune, one of India's most prestigious medical institutions.
                </p>
                <p>
                  Throughout his distinguished career, Mr. Singh has been committed to promoting oral health awareness, patient care, and excellence in dental services. His vast experience, leadership, and dedication have played a pivotal role in establishing Chambyal Dental Clinic as a trusted destination for quality dental treatment and compassionate patient care.
                </p>
                <p>
                  Known for his integrity, professionalism, and patient-first approach, Mr. Singh has guided the clinic with a vision of combining advanced dental technology with ethical and personalized treatment. His commitment to maintaining the highest standards of healthcare has earned the confidence and trust of countless patients over the decades.
                </p>
                <p>
                  As the driving force behind Chambyal Dental Clinic, he continues to inspire a culture of excellence, ensuring that every patient receives exceptional care in a comfortable and welcoming environment.
                </p>
                <p>
                  With four decades of experience, dedication, and service, Mr. Amarjit Singh remains committed to improving smiles and enhancing the oral health of the community.
                </p>
                <p className="font-bold border-t border-blue-200/55 pt-3 text-[#0F4C81] italic">
                  {doctorsData[2]?.treatmentPhilosophy}
                </p>
              </div>

              <div className="space-y-4 pt-2">
                <h4 className="text-xs font-bold text-slate-900 uppercase tracking-widest">Management & Prophylaxis Specialities:</h4>
                <div className="flex flex-wrap gap-2">
                  {doctorsData[2]?.specializations.map((spec, i) => (
                    <span key={i} className="px-3.5 py-1.5 bg-white border border-slate-200 text-slate-700 text-xs font-bold rounded-full">
                      {spec}
                    </span>
                  ))}
                </div>
              </div>

              <div className="pt-4 flex flex-col sm:flex-row gap-4">
                <button
                  onClick={() => {
                    setCurrentPage('doctor');
                    window.scrollTo({ top: 0, behavior: 'smooth' });
                  }}
                  className="px-6 py-3.5 bg-[#0F4C81] text-white hover:bg-[#0c3e6b] font-bold rounded-full text-xs shadow-md"
                >
                  View MD Biography & Qualifications
                </button>
                <a
                  href="tel:+919418366088"
                  className="px-6 py-3.5 bg-white text-slate-700 border border-slate-200 hover:bg-slate-50 font-semibold rounded-full text-xs text-center"
                >
                  Consult Directly: +91 94183 66088
                </a>
              </div>
            </div>

          </div>
        </div>
      </section>


      {/* ----------------- 6. BEFORE & AFTER GALLERY PREVIEW ----------------- */}
      <section className="py-24 max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-3xl mx-auto space-y-3 mb-16">
          <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest">Smile Transformation Showcase</span>
          <h2 className="text-3xl sm:text-4xl font-extrabold text-slate-900 tracking-tight">
            Before & After Smile Design Experience
          </h2>
          <p className="text-slate-500 text-sm leading-relaxed">
            Drag or hover on the image slider below to look closely at real clinical cosmetic alignment results.
          </p>
        </div>

        <div className="flex flex-col lg:flex-row items-center justify-center gap-16">
          
          {/* Active Image Slider */}
          <div className="w-full max-w-md space-y-4">
            <h4 className="text-sm font-bold text-slate-900 text-center tracking-tight">Porcelain Laminates & Dental Crowns Alignment</h4>
            
            <div 
              className="relative aspect-video w-full rounded-2xl overflow-hidden shadow-2xl border-4 border-white cursor-ew-resize select-none"
              onMouseMove={handleMobileHover}
              onTouchMove={handleMobileHover}
              id="smile-before-after-interaction-space"
            >
              {/* After Image (Background) */}
              <img 
                src="https://images.unsplash.com/photo-1588776814546-1ffcf47267a5?auto=format&fit=crop&q=80&w=800" 
                alt="After smile makeover therapy"
                referrerPolicy="no-referrer"
                className="absolute inset-0 w-full h-full object-cover pointer-events-none"
              />
              <div className="absolute bottom-3 right-3 px-2 py-1 bg-emerald-600/90 text-white rounded font-bold text-[10px] tracking-wide uppercase z-10">
                After Therapy
              </div>

              {/* Before Image (Foreground overlay) */}
              <div 
                className="absolute inset-0 pointer-events-none overflow-hidden"
                style={{ width: `${sliderPosition}%` }}
              >
                <img 
                  src="https://images.unsplash.com/photo-1629909615184-74f495363b67?auto=format&fit=crop&q=80&w=800" 
                  alt="Before smile design treatment mapping"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-cover max-w-none"
                  style={{ width: '440px', height: '247px' }} // fixed to avoid distortion during crop
                />
                <div className="absolute bottom-3 left-3 px-2 py-1 bg-red-600/90 text-white rounded font-bold text-[10px] tracking-wide uppercase z-10">
                  Before
                </div>
              </div>

              {/* Slider boundary drag line indicator */}
              <div 
                className="absolute top-0 bottom-0 w-1 bg-white hover:bg-slate-200 cursor-ew-resize z-20"
                style={{ left: `${sliderPosition}%` }}
              >
                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-xl flex items-center justify-center border border-slate-200">
                  <svg className="w-4 h-4 text-slate-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5">
                    <path d="M8 7l-5 5 5 5M16 7l5 5-5 5"/>
                  </svg>
                </div>
              </div>
            </div>
            
            <p className="text-center text-xs text-slate-500 font-semibold italic">
              Slide your mouse across the image to cycle between treatment states.
            </p>
          </div>

          {/* Core transform clinical description */}
          <div className="max-w-md space-y-6">
            <h3 className="text-xl font-bold text-slate-900 tracking-tight">Esthetic Rehabilitation Outcome</h3>
            <p className="text-slate-600 text-sm leading-relaxed">
              We resolve cosmetic irregularities, gaps, missing premolars, fluorosis staining, and cracked enamel. Treatments combine deep scanning, custom e-max translucent plates, and minor laser reshaping.
            </p>
            
            <div className="space-y-4">
              <div className="flex gap-3">
                <div className="w-5 h-5 rounded-full bg-[#20B2AA]/10 flex items-center justify-center shrink-0">
                  <span className="text-[#20B2AA] text-xs font-bold">1</span>
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-950">Aesthetic Metal-Free Durability</p>
                  <p className="text-xs text-slate-500 mt-0.5">Custom crowns feel precisely like a healthy premium tooth.</p>
                </div>
              </div>
              <div className="flex gap-3">
                <div className="w-5 h-5 rounded-full bg-[#20B2AA]/10 flex items-center justify-center shrink-0">
                  <span className="text-[#20B2AA] text-xs font-bold">2</span>
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-950">Perfect Anatomical Fit</p>
                  <p className="text-xs text-slate-500 mt-0.5">Designed dynamically following your exact facial axis geometry.</p>
                </div>
              </div>
            </div>

            <button
              onClick={() => {
                setCurrentPage('gallery');
                window.scrollTo({ top: 0, behavior: 'smooth' });
              }}
              className="px-6 py-3 bg-[#0F4C81] text-white hover:bg-[#0c3e6b] font-bold rounded-lg text-xs"
            >
              Tour Complete Transformation Gallery
            </button>
          </div>

        </div>
      </section>


      {/* ----------------- 7. PATIENT TESTIMONIALS & GOOGLE REVIEWS ----------------- */}
      <section className="py-24 bg-slate-100/70 border-t border-slate-250">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 mb-16 items-center">
            
            {/* Rating summary left */}
            <div className="lg:col-span-4 space-y-4 text-center lg:text-left">
              <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest block">Patient Verified Reviews</span>
              <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight leading-tight">
                What Our Patients Say About Us
              </h2>
              
              {/* Star breakdown */}
              <div className="p-6 bg-white rounded-3xl border border-slate-150 shadow-md">
                <p className="text-5xl font-extrabold text-slate-950 tracking-tighter">4.9</p>
                <div className="flex items-center justify-center lg:justify-start gap-1 py-2 text-amber-500">
                  {[...Array(5)].map((_, i) => (
                    <Star key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-slate-500 text-xs font-semibold">Average Google Rating</p>
                <div className="w-full bg-slate-100 h-2 rounded-full mt-3 overflow-hidden">
                  <div className="bg-[#20B2AA] h-full" style={{ width: '96%' }}></div>
                </div>
                <p className="text-slate-400 text-xs mt-1.5 font-medium">Based on 320+ patient evaluations</p>
              </div>

              {/* Requirement Widget Placeholder Container */}
              <div className="pt-2">
                <div className="p-4 bg-slate-950 text-white rounded-2xl border border-slate-900 text-center space-y-2">
                  <p className="text-[10px] text-slate-400 tracking-widest uppercase font-semibold">Google Review Map Widget</p>
                  <div id="google-review-widget" className="text-teal-400 font-bold text-[11px] truncate bg-slate-900 py-1.5 px-2 rounded border border-slate-800">
                    https://share.google/kwO9qTHNYp5vjrunX
                  </div>
                </div>
                
                <a
                  href="https://g.page/r/CXRLNZdDCtebEBM/review"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="mt-3 w-full inline-flex items-center justify-center gap-2 px-5 py-3 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white font-bold rounded-xl text-xs shadow-md shadow-blue-900/10 transition-transform hover:scale-[1.01]"
                  id="btn-rate-us-on-google"
                >
                  <Star className="w-4 h-4 fill-current text-white" />
                  <span>Rate Us on Google</span>
                </a>
              </div>

            </div>

            {/* Carousel-like Reviews grid right */}
            <div className="lg:col-span-8 grid grid-cols-1 md:grid-cols-2 gap-6">
              {reviewsData.map((rev) => (
                <div key={rev.id} className="bg-white p-6 md:p-8 rounded-3xl border border-slate-100 shadow-md flex flex-col justify-between">
                  <div>
                    <div className="flex items-center justify-between gap-4">
                      <div className="flex items-center gap-2.5">
                        <div className="w-10 h-10 rounded-full bg-[#0F4C81]/10 flex items-center justify-center font-bold text-[#0F4C81] text-sm object-cover">
                          {rev.authorName[0]}
                        </div>
                        <div>
                          <p className="text-sm font-bold text-slate-900">{rev.authorName}</p>
                          <p className="text-slate-400 text-[11px] font-semibold">{rev.reviewDate}</p>
                        </div>
                      </div>
                      
                      <div className="flex gap-0.5 text-amber-500">
                        {[...Array(rev.rating)].map((_, idx) => (
                          <Star key={idx} className="w-3.5 h-3.5 fill-current" />
                        ))}
                      </div>
                    </div>

                    <p className="text-slate-700 text-xs leading-relaxed mt-4">
                      "{rev.comment}"
                    </p>
                  </div>

                  {rev.verified && (
                    <div className="mt-4 pt-3 border-t border-slate-50 flex items-center gap-1.5 text-emerald-600 text-[10px] font-bold">
                      <CheckCircle className="w-3.5 h-3.5" />
                      <span>Verified Patient Visit</span>
                    </div>
                  )}
                </div>
              ))}
            </div>

          </div>

        </div>
      </section>


      {/* ----------------- 8. FAQ SECTION ----------------- */}
      <section className="py-24 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center max-w-2xl mx-auto space-y-3 mb-16">
          <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest">Frequently Inquired Questions</span>
          <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight">
            Common Patient Questions Answered
          </h2>
          <p className="text-slate-500 text-sm">
            Review detailed guidelines on budgets, RCT workflows, and clinic protocols.
          </p>
        </div>

        <div className="space-y-4" id="faq-accordions-group">
          {faqsData.map((faq) => {
            const isOpen = activeFaq === faq.id;
            return (
              <div 
                key={faq.id} 
                className="bg-white border border-slate-200/80 rounded-2xl overflow-hidden transition-all duration-300"
              >
                <button
                  onClick={() => setActiveFaq(isOpen ? null : faq.id)}
                  className="w-full px-6 py-5 text-left flex items-center justify-between gap-4 font-semibold text-sm sm:text-base text-slate-900 hover:bg-slate-50 transition-colors"
                >
                  <span>{faq.question}</span>
                  <span className="shrink-0 text-slate-400">
                    {isOpen ? <Minus className="w-5 h-5 text-[#0F4C81]" /> : <Plus className="w-5 h-5" />}
                  </span>
                </button>

                <AnimatePresence>
                  {isOpen && (
                    <motion.div
                      initial={{ height: 0, opacity: 0 }}
                      animate={{ height: 'auto', opacity: 1 }}
                      exit={{ height: 0, opacity: 0 }}
                      transition={{ duration: 0.25 }}
                    >
                      <div className="px-6 pb-6 text-slate-500 text-xs sm:text-sm leading-relaxed border-t border-slate-100 pt-3">
                        {faq.answer}
                      </div>
                    </motion.div>
                  )}
                </AnimatePresence>
              </div>
            );
          })}
        </div>
      </section>


      {/* ----------------- 9. GOOGLE MAPS LOCATION SECTION ----------------- */}
      <section className="py-24 bg-white border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
            
            {/* Quick address and info Left */}
            <div className="lg:col-span-5 space-y-6">
              <span className="text-[#0F4C81] font-bold text-xs uppercase tracking-widest block">Find Us on Google Maps</span>
              <h2 className="text-3xl font-extrabold text-slate-950 tracking-tight leading-tight">
                Our Hospital Location in Barsar
              </h2>
              <p className="text-slate-600 text-sm leading-relaxed font-semibold">
                Chambyal Dental Clinic, Main Market Barsar, Near Bus Stand, Barsar, Hamirpur, Himachal Pradesh - 174305
              </p>

              <div className="space-y-4">
                <div className="flex gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#20B2AA]/10 flex items-center justify-center shrink-0">
                    <Clock className="w-4.5 h-4.5 text-[#20B2AA]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-950">Daily Operating Timings</p>
                    <p className="text-xs text-slate-500 mt-0.5">Monday - Saturday: 09:30 AM to 06:30 PM (Sunday Protected Scheduling)</p>
                  </div>
                </div>

                <div className="flex gap-3">
                  <div className="w-9 h-9 rounded-xl bg-[#20B2AA]/10 flex items-center justify-center shrink-0">
                    <MapPin className="w-4.5 h-4.5 text-[#20B2AA]" />
                  </div>
                  <div>
                    <p className="text-xs font-bold text-slate-950">Landmark Spot</p>
                    <p className="text-xs text-slate-500 mt-0.5">Directly adjacent to Main Bus Stand, opposite local market corridor.</p>
                  </div>
                </div>
              </div>

              {/* Requirement action buttons */}
              <div className="flex flex-wrap gap-3 pt-2">
                <a
                  href="https://maps.app.goo.gl/BoWTSAnezZBmPDXF8"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-6 py-3 bg-[#0F4C81] text-white hover:bg-[#0c3e6b] font-bold text-xs rounded-xl flex items-center gap-2 shadow"
                  id="google-maps-directions-link"
                >
                  <MapPin className="w-4 h-4 text-teal-400" />
                  <span>Get Driving Directions</span>
                </a>
                <a
                  href={`tel:${clinicPhone}`}
                  className="px-6 py-3 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold text-xs rounded-xl flex items-center gap-2"
                >
                  <Phone className="w-4 h-4 text-slate-500" />
                  <span>Call Reception Desk</span>
                </a>
              </div>
            </div>

            {/* Embed IFrame mapping Right */}
            <div className="lg:col-span-7 relative h-[400px] w-full rounded-2xl overflow-hidden shadow-2xl border border-slate-200">
              {/* Mandatory Embed Code placeholder request */}
              <iframe 
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3419.6455113945!2d76.4385!3d31.5714!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x0%3A0x0!2zMzHCsDM0JzE3LjAiTiA3NisyNicyOC42IkU!5e0!3m2!1sen!2sin!4v1620000000000!5m2!1sen!2sin"
                title="Chambyal Dental Clinic Location Map"
                className="absolute inset-0 w-full h-full border-0" 
                allowFullScreen={true}
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
              ></iframe>
            </div>

          </div>

        </div>
      </section>


      {/* ----------------- 10. CONTACT CTA SPLIT BANNER ----------------- */}
      <section className="bg-gradient-to-r from-[#0F4C81] to-[#20B2AA] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col lg:flex-row items-center justify-between gap-8">
          <div className="space-y-3 text-center lg:text-left max-w-3xl">
            <h3 className="text-3xl font-extrabold tracking-tight">Schedule Your Consultation Sessions Today</h3>
            <p className="text-blue-50/90 text-sm">
              Do not let dental pain interrupt your health. Meet gold-medalist Dr. Ankush Chambyal and begin your transformation journey.
            </p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4 w-full lg:w-auto shrink-0 justify-center">
            <button
              onClick={() => handleBookNow('')}
              className="px-8 py-4 bg-white text-[#0F4C81] hover:bg-slate-50 font-bold rounded-full text-sm text-center shadow-lg hover:scale-105 transition-all"
            >
              Reserve Slot Online
            </button>
            <a
              href={`tel:${clinicPhone}`}
              className="px-8 py-4 bg-slate-950/40 hover:bg-slate-950/60 text-white rounded-full font-bold text-sm text-center border border-white/25 hover:scale-105 transition-all"
            >
              Direct Call Support
            </a>
          </div>
        </div>
      </section>

    </motion.div>
  );
}
