import { useState } from 'react';
import { servicesData } from '../data';
import { 
  Plus, 
  Minus, 
  Calendar, 
  CheckCircle, 
  ArrowRight,
  Shield,
  Heart,
  Sparkles,
  Layers,
  Baby,
  Activity,
  Scissors,
  Grid3X3,
  HeartHandshake
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

interface ServicesProps {
  setCurrentPage: (page: string) => void;
  setSelectedTreatment?: (treatment: string) => void;
}

// Custom mapping for dynamic icons based on name keys inside data.ts
const iconMap: { [key: string]: any } = {
  ShieldAlert: Shield,
  Activity: Activity,
  Sparkles: Sparkles,
  Smile: Sparkles, // Smile uses sparkles or custom indicator
  Layers: Layers,
  Heart: Heart,
  Grid: Grid3X3,
  Baby: Baby,
  Scissors: Scissors,
  Grid3X3: Grid3X3,
  HeartHandshake: HeartHandshake
};

export default function Services({ setCurrentPage, setSelectedTreatment }: ServicesProps) {
  const [expandedServiceId, setExpandedServiceId] = useState<string | null>(null);
  const [selectedFilter, setSelectedFilter] = useState<string>('all');

  const filterTabs = [
    { id: 'all', label: 'All 12 Treatments' },
    { id: 'implant-surgical', label: 'Implants & Surgery' },
    { id: 'restorative-endodontic', label: 'Root Canal & Restorations' },
    { id: 'cosmetic-esthetic', label: 'Cosmetic & Smile Art' },
    { id: 'family-guard', label: 'Preventive & Kids Care' }
  ];

  // Map service ID to simple categories for active client filtering
  const getServiceCategory = (id: string): string => {
    switch (id) {
      case 'implants':
      case 'oral-surgery':
        return 'implant-surgical';
      case 'rct':
      case 'crowns':
      case 'complete-dentures':
      case 'partial-dentures':
        return 'restorative-endodontic';
      case 'whitening':
      case 'smile-design':
      case 'orthodontics':
        return 'cosmetic-esthetic';
      case 'pediatric':
      case 'gum-treatment':
      case 'preventive':
        return 'family-guard';
      default:
        return 'all';
    }
  };

  const filteredServices = servicesData.filter((ser) => {
    if (selectedFilter === 'all') return true;
    return getServiceCategory(ser.id) === selectedFilter;
  });

  const handleBookService = (serviceId: string) => {
    if (setSelectedTreatment) {
      setSelectedTreatment(serviceId);
    }
    setCurrentPage('booking');
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <motion.div
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
      className="bg-[#F8FAFC] py-16 min-h-screen"
      id="services-exploration-page"
    >
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        
        {/* Header Title section */}
        <div className="text-center max-w-3xl mx-auto space-y-4 mb-16">
          <span className="text-[#0F4C81] text-xs font-bold uppercase tracking-widest block">Comprehensive Dental Protocols</span>
          <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-900 tracking-tight leading-tight">
            Our Professional Dental Services
          </h1>
          <p className="text-slate-600 text-sm leading-relaxed">
            From emergency pain Relief to complex bone implants, Dr. Ankush Chambyal combines decades of research with premium certified dental composites for dental perfection.
          </p>
        </div>

        {/* Filter categories tabs ribbon */}
        <div className="flex flex-wrap justify-center gap-3 mb-16" id="services-category-filtering-ribbon">
          {filterTabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setSelectedFilter(tab.id)}
              className={`px-5 py-2.5 rounded-full text-xs font-bold tracking-wide transition-all border ${
                selectedFilter === tab.id
                  ? 'bg-[#0F4C81] text-white border-[#0F4C81] shadow-md shadow-blue-900/10'
                  : 'bg-white border-slate-200 text-slate-600 hover:border-slate-350 hover:bg-slate-50'
              }`}
              id={`filter-tab-${tab.id}`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Services Listings Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8" id="treatment-services-cards-grid">
          {filteredServices.map((ser) => {
            const IconComponent = iconMap[ser.iconName] || Shield;
            const isExpanded = expandedServiceId === ser.id;

            return (
              <div 
                key={ser.id} 
                className="bg-white rounded-3xl border border-slate-150 shadow-md hover:shadow-xl transition-all duration-300 overflow-hidden flex flex-col justify-between group"
                id={`service-card-${ser.id}`}
              >
                
                {/* Visual Image Banner with Icon inside */}
                <div className="h-52 relative overflow-hidden">
                  <img
                    src={ser.imageUrl}
                    alt={ser.title}
                    referrerPolicy="no-referrer"
                    className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-slate-950/40 via-slate-950/10 to-transparent"></div>
                  
                  {/* Category Chip Badge */}
                  <div className="absolute top-4 left-4 px-3 py-1 bg-[#20B2AA] text-white rounded-full text-[10px] font-extrabold uppercase tracking-widest shadow-md">
                    {ser.id === 'implants' || ser.id === 'rct' || ser.id === 'smile-design' ? 'Premium Speciality' : 'Standard Routine'}
                  </div>

                  {/* Icon badge floating at bottom right */}
                  <div className="absolute bottom-4 right-4 w-10 h-10 rounded-xl bg-white/95 backdrop-blur-sm shadow flex items-center justify-center text-[#0F4C81]">
                    <IconComponent className="w-5 h-5" />
                  </div>
                </div>

                {/* Primary Card Details */}
                <div className="p-6 sm:p-8 flex-1 flex flex-col justify-between">
                  
                  <div className="space-y-3">
                    <h3 className="text-xl font-bold text-slate-950 group-hover:text-[#0F4C81] transition-colors tracking-tight leading-snug">
                      {ser.title}
                    </h3>
                    <p className="text-slate-600 text-xs sm:text-sm leading-relaxed">
                      {ser.shortDescription}
                    </p>

                    {/* Expandable detailed content element */}
                    <AnimatePresence>
                      {isExpanded && (
                        <motion.div
                          initial={{ height: 0, opacity: 0 }}
                          animate={{ height: 'auto', opacity: 1 }}
                          exit={{ height: 0, opacity: 0 }}
                          transition={{ duration: 0.3 }}
                          className="overflow-hidden bg-slate-50 border border-slate-100 rounded-2xl p-4 mt-4 space-y-3"
                        >
                          <p className="text-xs text-slate-500 leading-relaxed font-semibold">
                            {ser.description}
                          </p>
                          
                          <div>
                            <p className="text-[11px] font-bold text-slate-900 uppercase tracking-wider mb-2">Key Benefits:</p>
                            <ul className="space-y-2">
                              {ser.benefits.map((ben, index) => (
                                <li key={index} className="flex items-start gap-2 text-xs text-slate-600">
                                  <CheckCircle className="w-3.5 h-3.5 text-emerald-500 shrink-0 mt-0.5" />
                                  <span>{ben}</span>
                                </li>
                              ))}
                            </ul>
                          </div>

                        </motion.div>
                      )}
                    </AnimatePresence>
                  </div>

                  {/* Operational buttons group */}
                  <div className="mt-8 pt-5 border-t border-slate-50 space-y-3">
                    <button
                      onClick={() => setExpandedServiceId(isExpanded ? null : ser.id)}
                      className="w-full py-2 bg-slate-50 hover:bg-slate-150 text-slate-700 font-bold text-xs rounded-xl flex items-center justify-center gap-1.5 transition-colors"
                      id={`btn-expand-service-${ser.id}`}
                    >
                      <span>{isExpanded ? 'Less technical Details' : 'Learn Patient Benefits'}</span>
                      {isExpanded ? <Minus className="w-3.5 h-3.5" /> : <Plus className="w-3.5 h-3.5" />}
                    </button>
                    
                    <button
                      onClick={() => handleBookService(ser.id)}
                      className="w-full py-3 bg-[#0F4C81] hover:bg-[#0c3e6b] text-white font-extrabold text-xs rounded-xl flex items-center justify-center gap-2 transform active:scale-98 transition-all shadow shadow-blue-900/10"
                      id={`btn-book-service-consult-${ser.id}`}
                    >
                      <Calendar className="w-3.5 h-3.5" />
                      <span>Book Consultation</span>
                    </button>
                  </div>

                </div>

              </div>
            );
          })}
        </div>

        {/* Custom Schema QA Banner block */}
        <div className="mt-24 p-8 sm:p-12 bg-slate-900 text-white rounded-3xl relative overflow-hidden shadow-xl border border-slate-800">
          <div className="absolute top-0 right-0 w-80 h-80 bg-[#20B2AA]/10 rounded-full blur-3xl"></div>
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-center">
            <div className="lg:col-span-8 space-y-4">
              <span className="text-[#20B2AA] font-bold text-xs uppercase tracking-widest block">Personalized Treatment Plans</span>
              <h3 className="text-2xl sm:text-3xl font-extrabold tracking-tight">Need Help Choosing the Right Service?</h3>
              <p className="text-slate-400 text-xs sm:text-sm leading-relaxed">
                If you suffer from continuous toothaches, swelling, missing bridges, or simply wish to scale stains, book an entry consult. Our gold-medalist implantologists will analyze your oral cavity via a digital 3D intraoral scan.
              </p>
            </div>
            <div className="lg:col-span-4 flex flex-col sm:flex-row lg:flex-col gap-3 w-full justify-end">
              <button
                onClick={() => handleBookService('')}
                className="px-6 py-3.5 bg-[#20B2AA] hover:bg-teal-500 text-white font-bold rounded-xl text-xs text-center shadow shadow-teal-500/20"
              >
                Schedule diagnostic Check
              </button>
              <a
                href="tel:+919459778337"
                className="px-6 py-3.5 bg-white/5 border border-white/10 hover:bg-white/10 text-white text-center rounded-xl text-xs font-bold"
              >
                Call Hotline Direct
              </a>
            </div>
          </div>
        </div>

      </div>
    </motion.div>
  );
}
