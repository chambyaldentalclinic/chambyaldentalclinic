export interface DentalService {
  id: string;
  title: string;
  shortDescription: string;
  description: string;
  benefits: string[];
  imageUrl: string;
  iconName: string; // Used to dynamically map Lucide icons
}

export interface PatientReview {
  id: string;
  authorName: string;
  reviewDate: string;
  rating: number;
  comment: string;
  avatarUrl?: string;
  verified: boolean;
}

export interface FAQItem {
  id: string;
  question: string;
  answer: string;
  category: string;
}

export interface DoctorProfile {
  name: string;
  title: string;
  degrees: string[];
  specializations: string[];
  experienceYears: number;
  biography: string[];
  treatmentPhilosophy: string;
  achievements: string[];
  imageUrl: string;
}

export interface GalleryItem {
  id: string;
  title: string;
  category: 'interior' | 'equipment' | 'treatment' | 'transformation';
  imageUrl: string;
  description?: string;
}

export interface AppointmentInput {
  name: string;
  phone: string;
  email: string;
  preferredDate: string;
  preferredTime: string;
  treatmentId: string;
  message: string;
}
